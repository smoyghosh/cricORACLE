function getCountries(){
	var countryIndustries = {
		"IsSuccess": "true",
		"countryContent": [{
			"c_id": "1",
			"country_nm": "Afghanistan",
			"c_phone_prefix": "93",
			"iso": "AF"
		},
		{
			"c_id": "2",
			"country_nm": "Aland Islands",
			"c_phone_prefix": "+358-18",
			"iso": "AX"
		},
		{
			"c_id": "3",
			"country_nm": "Albania",
			"c_phone_prefix": "355",
			"iso": "AL"
		},
		{
			"c_id": "4",
			"country_nm": "Algeria",
			"c_phone_prefix": "213",
			"iso": "DZ"
		},
		{
			"c_id": "5",
			"country_nm": "American Samoa",
			"c_phone_prefix": "+1-684",
			"iso": "AS"
		},
		{
			"c_id": "6",
			"country_nm": "Andorra",
			"c_phone_prefix": "376",
			"iso": "AD"
		},
		{
			"c_id": "7",
			"country_nm": "Angola",
			"c_phone_prefix": "244",
			"iso": "AO"
		},
		{
			"c_id": "8",
			"country_nm": "Anguilla",
			"c_phone_prefix": "+1-264",
			"iso": "AI"
		},
		{
			"c_id": "9",
			"country_nm": "Antarctica",
			"c_phone_prefix": "+672",
			"iso": "AQ"
		},
		{
			"c_id": "10",
			"country_nm": "Antigua and Barbuda",
			"c_phone_prefix": "+1-268",
			"iso": "AG"
		},
		{
			"c_id": "11",
			"country_nm": "Argentina",
			"c_phone_prefix": "54",
			"iso": "AR"
		},
		{
			"c_id": "12",
			"country_nm": "Armenia",
			"c_phone_prefix": "374",
			"iso": "AM"
		},
		{
			"c_id": "13",
			"country_nm": "Aruba",
			"c_phone_prefix": "297",
			"iso": "AW"
		},
		{
			"c_id": "14",
			"country_nm": "Australia",
			"c_phone_prefix": "61",
			"iso": "AU"
		},
		{
			"c_id": "15",
			"country_nm": "Austria",
			"c_phone_prefix": "43",
			"iso": "AT"
		},
		{
			"c_id": "16",
			"country_nm": "Azerbaijan",
			"c_phone_prefix": "994",
			"iso": "AZ"
		},
		{
			"c_id": "17",
			"country_nm": "Bahamas",
			"c_phone_prefix": "+1-242",
			"iso": "BS"
		},
		{
			"c_id": "18",
			"country_nm": "Bahrain",
			"c_phone_prefix": "973",
			"iso": "BH"
		},
		{
			"c_id": "19",
			"country_nm": "Bangladesh",
			"c_phone_prefix": "880",
			"iso": "BD"
		},
		{
			"c_id": "20",
			"country_nm": "Barbados",
			"c_phone_prefix": "+1-246",
			"iso": "BB"
		},
		{
			"c_id": "21",
			"country_nm": "Belarus",
			"c_phone_prefix": "375",
			"iso": "BY"
		},
		{
			"c_id": "22",
			"country_nm": "Belgium",
			"c_phone_prefix": "32",
			"iso": "BE"
		},
		{
			"c_id": "23",
			"country_nm": "Belize",
			"c_phone_prefix": "501",
			"iso": "BZ"
		},
		{
			"c_id": "24",
			"country_nm": "Benin",
			"c_phone_prefix": "229",
			"iso": "BJ"
		},
		{
			"c_id": "25",
			"country_nm": "Bermuda",
			"c_phone_prefix": "+1-441",
			"iso": "BM"
		},
		{
			"c_id": "26",
			"country_nm": "Bhutan",
			"c_phone_prefix": "975",
			"iso": "BT"
		},
		{
			"c_id": "27",
			"country_nm": "Bolivia",
			"c_phone_prefix": "591",
			"iso": "BO"
		},
		{
			"c_id": "28",
			"country_nm": "Bosnia and Herzegovina",
			"c_phone_prefix": "387",
			"iso": "BA"
		},
		{
			"c_id": "29",
			"country_nm": "Botswana",
			"c_phone_prefix": "267",
			"iso": "BW"
		},
		{
			"c_id": "245",
			"country_nm": "Bouvet Island",
			"c_phone_prefix": "+47",
			"iso": "BV"
		},
		{
			"c_id": "31",
			"country_nm": "Brazil",
			"c_phone_prefix": "55",
			"iso": "BR"
		},
		{
			"c_id": "32",
			"country_nm": "British Indian Ocean Territory",
			"c_phone_prefix": "246",
			"iso": "IO"
		},
		{
			"c_id": "238",
			"country_nm": "British Virgin Islands",
			"c_phone_prefix": "+1-284",
			"iso": "VG"
		},
		{
			"c_id": "33",
			"country_nm": "Brunei",
			"c_phone_prefix": "673",
			"iso": "BN"
		},
		{
			"c_id": "34",
			"country_nm": "Bulgaria",
			"c_phone_prefix": "359",
			"iso": "BG"
		},
		{
			"c_id": "35",
			"country_nm": "Burkina Faso",
			"c_phone_prefix": "226",
			"iso": "BF"
		},
		{
			"c_id": "36",
			"country_nm": "Burundi",
			"c_phone_prefix": "257",
			"iso": "BI"
		},
		{
			"c_id": "37",
			"country_nm": "Cambodia",
			"c_phone_prefix": "855",
			"iso": "KH"
		},
		{
			"c_id": "38",
			"country_nm": "Cameroon",
			"c_phone_prefix": "237",
			"iso": "CM"
		},
		{
			"c_id": "39",
			"country_nm": "Canada",
			"c_phone_prefix": "1",
			"iso": "CA"
		},
		{
			"c_id": "40",
			"country_nm": "Cape Verde",
			"c_phone_prefix": "238",
			"iso": "CV"
		},
		{
			"c_id": "41",
			"country_nm": "Cayman Islands",
			"c_phone_prefix": "+1-345",
			"iso": "KY"
		},
		{
			"c_id": "42",
			"country_nm": "Central African Republic",
			"c_phone_prefix": "236",
			"iso": "CF"
		},
		{
			"c_id": "43",
			"country_nm": "Chad",
			"c_phone_prefix": "235",
			"iso": "TD"
		},
		{
			"c_id": "44",
			"country_nm": "Chile",
			"c_phone_prefix": "56",
			"iso": "CL"
		},
		{
			"c_id": "45",
			"country_nm": "China",
			"c_phone_prefix": "86",
			"iso": "CN"
		},
		{
			"c_id": "46",
			"country_nm": "Christmas Island",
			"c_phone_prefix": "61",
			"iso": "CX"
		},
		{
			"c_id": "47",
			"country_nm": "Cocos Islands",
			"c_phone_prefix": "61",
			"iso": "CC"
		},
		{
			"c_id": "48",
			"country_nm": "Colombia",
			"c_phone_prefix": "57",
			"iso": "CO"
		},
		{
			"c_id": "49",
			"country_nm": "Comoros",
			"c_phone_prefix": "269",
			"iso": "KM"
		},
		{
			"c_id": "52",
			"country_nm": "Cook Islands",
			"c_phone_prefix": "682",
			"iso": "CK"
		},
		{
			"c_id": "53",
			"country_nm": "Costa Rica",
			"c_phone_prefix": "506",
			"iso": "CR"
		},
		{
			"c_id": "55",
			"country_nm": "Croatia",
			"c_phone_prefix": "385",
			"iso": "HR"
		},
		{
			"c_id": "56",
			"country_nm": "Cuba",
			"c_phone_prefix": "53",
			"iso": "CU"
		},
		{
			"c_id": "57",
			"country_nm": "Cyprus",
			"c_phone_prefix": "357",
			"iso": "CY"
		},
		{
			"c_id": "58",
			"country_nm": "Czech Republic",
			"c_phone_prefix": "420",
			"iso": "CZ"
		},
		{
			"c_id": "51",
			"country_nm": "Democratic Republic of the Congo",
			"c_phone_prefix": "243",
			"iso": "CD"
		},
		{
			"c_id": "59",
			"country_nm": "Denmark",
			"c_phone_prefix": "45",
			"iso": "DK"
		},
		{
			"c_id": "60",
			"country_nm": "Djibouti",
			"c_phone_prefix": "253",
			"iso": "DJ"
		},
		{
			"c_id": "61",
			"country_nm": "Dominica",
			"c_phone_prefix": "+1-767",
			"iso": "DM"
		},
		{
			"c_id": "62",
			"country_nm": "Dominican Republic",
			"c_phone_prefix": "+1-809 and 1-829",
			"iso": "DO"
		},
		{
			"c_id": "217",
			"country_nm": "East Timor",
			"c_phone_prefix": "670",
			"iso": "TL"
		},
		{
			"c_id": "63",
			"country_nm": "Ecuador",
			"c_phone_prefix": "593",
			"iso": "EC"
		},
		{
			"c_id": "64",
			"country_nm": "Egypt",
			"c_phone_prefix": "20",
			"iso": "EG"
		},
		{
			"c_id": "65",
			"country_nm": "El Salvador",
			"c_phone_prefix": "503",
			"iso": "SV"
		},
		{
			"c_id": "66",
			"country_nm": "Equatorial Guinea",
			"c_phone_prefix": "240",
			"iso": "GQ"
		},
		{
			"c_id": "67",
			"country_nm": "Eritrea",
			"c_phone_prefix": "291",
			"iso": "ER"
		},
		{
			"c_id": "68",
			"country_nm": "Estonia",
			"c_phone_prefix": "372",
			"iso": "EE"
		},
		{
			"c_id": "69",
			"country_nm": "Ethiopia",
			"c_phone_prefix": "251",
			"iso": "ET"
		},
		{
			"c_id": "70",
			"country_nm": "Falkland Islands",
			"c_phone_prefix": "500",
			"iso": "FK"
		},
		{
			"c_id": "71",
			"country_nm": "Faroe Islands",
			"c_phone_prefix": "298",
			"iso": "FO"
		},
		{
			"c_id": "72",
			"country_nm": "Fiji",
			"c_phone_prefix": "679",
			"iso": "FJ"
		},
		{
			"c_id": "73",
			"country_nm": "Finland",
			"c_phone_prefix": "358",
			"iso": "FI"
		},
		{
			"c_id": "74",
			"country_nm": "France",
			"c_phone_prefix": "33",
			"iso": "FR"
		},
		{
			"c_id": "75",
			"country_nm": "French Guiana",
			"c_phone_prefix": "594",
			"iso": "GF"
		},
		{
			"c_id": "76",
			"country_nm": "French Polynesia",
			"c_phone_prefix": "689",
			"iso": "PF"
		},
		{
			"c_id": "77",
			"country_nm": "French Southern Territories",
			"c_phone_prefix": "+262",
			"iso": "TF"
		},
		{
			"c_id": "78",
			"country_nm": "Gabon",
			"c_phone_prefix": "241",
			"iso": "GA"
		},
		{
			"c_id": "79",
			"country_nm": "Gambia",
			"c_phone_prefix": "220",
			"iso": "GM"
		},
		{
			"c_id": "80",
			"country_nm": "Georgia",
			"c_phone_prefix": "995",
			"iso": "GE"
		},
		{
			"c_id": "81",
			"country_nm": "Germany",
			"c_phone_prefix": "49",
			"iso": "DE"
		},
		{
			"c_id": "82",
			"country_nm": "Ghana",
			"c_phone_prefix": "233",
			"iso": "GH"
		},
		{
			"c_id": "83",
			"country_nm": "Gibraltar",
			"c_phone_prefix": "350",
			"iso": "GI"
		},
		{
			"c_id": "84",
			"country_nm": "Greece",
			"c_phone_prefix": "30",
			"iso": "GR"
		},
		{
			"c_id": "85",
			"country_nm": "Greenland",
			"c_phone_prefix": "299",
			"iso": "GL"
		},
		{
			"c_id": "86",
			"country_nm": "Grenada",
			"c_phone_prefix": "+1-473",
			"iso": "GD"
		},
		{
			"c_id": "87",
			"country_nm": "Guadeloupe",
			"c_phone_prefix": "590",
			"iso": "GP"
		},
		{
			"c_id": "88",
			"country_nm": "Guam",
			"c_phone_prefix": "+1-671",
			"iso": "GU"
		},
		{
			"c_id": "89",
			"country_nm": "Guatemala",
			"c_phone_prefix": "502",
			"iso": "GT"
		},
		{
			"c_id": "90",
			"country_nm": "Guernsey",
			"c_phone_prefix": "+44-1481",
			"iso": "GG"
		},
		{
			"c_id": "91",
			"country_nm": "Guinea",
			"c_phone_prefix": "224",
			"iso": "GN"
		},
		{
			"c_id": "92",
			"country_nm": "Guinea-Bissau",
			"c_phone_prefix": "245",
			"iso": "GW"
		},
		{
			"c_id": "93",
			"country_nm": "Guyana",
			"c_phone_prefix": "592",
			"iso": "GY"
		},
		{
			"c_id": "94",
			"country_nm": "Haiti",
			"c_phone_prefix": "509",
			"iso": "HT"
		},
		{
			"c_id": "97",
			"country_nm": "Honduras",
			"c_phone_prefix": "504",
			"iso": "HN"
		},
		{
			"c_id": "98",
			"country_nm": "Hong Kong",
			"c_phone_prefix": "852",
			"iso": "HK"
		},
		{
			"c_id": "99",
			"country_nm": "Hungary",
			"c_phone_prefix": "36",
			"iso": "HU"
		},
		{
			"c_id": "100",
			"country_nm": "Iceland",
			"c_phone_prefix": "354",
			"iso": "IS"
		},
		{
			"c_id": "101",
			"country_nm": "India",
			"c_phone_prefix": "91",
			"iso": "IN"
		},
		{
			"c_id": "102",
			"country_nm": "Indonesia",
			"c_phone_prefix": "62",
			"iso": "ID"
		},
		{
			"c_id": "103",
			"country_nm": "Iran",
			"c_phone_prefix": "98",
			"iso": "IR"
		},
		{
			"c_id": "104",
			"country_nm": "Iraq",
			"c_phone_prefix": "964",
			"iso": "IQ"
		},
		{
			"c_id": "105",
			"country_nm": "Ireland",
			"c_phone_prefix": "353",
			"iso": "IE"
		},
		{
			"c_id": "106",
			"country_nm": "Isle of Man",
			"c_phone_prefix": "+44-1624",
			"iso": "IM"
		},
		{
			"c_id": "107",
			"country_nm": "Israel",
			"c_phone_prefix": "972",
			"iso": "IL"
		},
		{
			"c_id": "108",
			"country_nm": "Italy",
			"c_phone_prefix": "39",
			"iso": "IT"
		},
		{
			"c_id": "54",
			"country_nm": "Ivory Coast",
			"c_phone_prefix": "225",
			"iso": "CI"
		},
		{
			"c_id": "109",
			"country_nm": "Jamaica",
			"c_phone_prefix": "+1-876",
			"iso": "JM"
		},
		{
			"c_id": "110",
			"country_nm": "Japan",
			"c_phone_prefix": "81",
			"iso": "JP"
		},
		{
			"c_id": "111",
			"country_nm": "Jersey",
			"c_phone_prefix": "+44-1534",
			"iso": "JE"
		},
		{
			"c_id": "112",
			"country_nm": "Jordan",
			"c_phone_prefix": "962",
			"iso": "JO"
		},
		{
			"c_id": "113",
			"country_nm": "Kazakhstan",
			"c_phone_prefix": "7",
			"iso": "KZ"
		},
		{
			"c_id": "114",
			"country_nm": "Kenya",
			"c_phone_prefix": "254",
			"iso": "KE"
		},
		{
			"c_id": "115",
			"country_nm": "Kiribati",
			"c_phone_prefix": "686",
			"iso": "KI"
		},
		{
			"c_id": "855",
			"country_nm": "Kosovo",
			"c_phone_prefix": "+381",
			"iso": "XK"
		},
		{
			"c_id": "118",
			"country_nm": "Kuwait",
			"c_phone_prefix": "965",
			"iso": "KW"
		},
		{
			"c_id": "119",
			"country_nm": "Kyrgyzstan",
			"c_phone_prefix": "996",
			"iso": "KG"
		},
		{
			"c_id": "120",
			"country_nm": "Laos",
			"c_phone_prefix": "856",
			"iso": "LA"
		},
		{
			"c_id": "121",
			"country_nm": "Latvia",
			"c_phone_prefix": "371",
			"iso": "LV"
		},
		{
			"c_id": "122",
			"country_nm": "Lebanon",
			"c_phone_prefix": "961",
			"iso": "LB"
		},
		{
			"c_id": "123",
			"country_nm": "Lesotho",
			"c_phone_prefix": "266",
			"iso": "LS"
		},
		{
			"c_id": "124",
			"country_nm": "Liberia",
			"c_phone_prefix": "231",
			"iso": "LR"
		},
		{
			"c_id": "125",
			"country_nm": "Libya",
			"c_phone_prefix": "218",
			"iso": "LY"
		},
		{
			"c_id": "126",
			"country_nm": "Liechtenstein",
			"c_phone_prefix": "423",
			"iso": "LI"
		},
		{
			"c_id": "127",
			"country_nm": "Lithuania",
			"c_phone_prefix": "370",
			"iso": "LT"
		},
		{
			"c_id": "128",
			"country_nm": "Luxembourg",
			"c_phone_prefix": "352",
			"iso": "LU"
		},
		{
			"c_id": "129",
			"country_nm": "Macao",
			"c_phone_prefix": "853",
			"iso": "MO"
		},
		{
			"c_id": "130",
			"country_nm": "Macedonia",
			"c_phone_prefix": "389",
			"iso": "MK"
		},
		{
			"c_id": "131",
			"country_nm": "Madagascar",
			"c_phone_prefix": "261",
			"iso": "MG"
		},
		{
			"c_id": "132",
			"country_nm": "Malawi",
			"c_phone_prefix": "265",
			"iso": "MW"
		},
		{
			"c_id": "133",
			"country_nm": "Malaysia",
			"c_phone_prefix": "60",
			"iso": "MY"
		},
		{
			"c_id": "134",
			"country_nm": "Maldives",
			"c_phone_prefix": "960",
			"iso": "MV"
		},
		{
			"c_id": "135",
			"country_nm": "Mali",
			"c_phone_prefix": "223",
			"iso": "ML"
		},
		{
			"c_id": "136",
			"country_nm": "Malta",
			"c_phone_prefix": "356",
			"iso": "MT"
		},
		{
			"c_id": "137",
			"country_nm": "Marshall Islands",
			"c_phone_prefix": "692",
			"iso": "MH"
		},
		{
			"c_id": "138",
			"country_nm": "Martinique",
			"c_phone_prefix": "596",
			"iso": "MQ"
		},
		{
			"c_id": "139",
			"country_nm": "Mauritania",
			"c_phone_prefix": "222",
			"iso": "MR"
		},
		{
			"c_id": "140",
			"country_nm": "Mauritius",
			"c_phone_prefix": "230",
			"iso": "MU"
		},
		{
			"c_id": "141",
			"country_nm": "Mayotte",
			"c_phone_prefix": "269",
			"iso": "YT"
		},
		{
			"c_id": "142",
			"country_nm": "Mexico",
			"c_phone_prefix": "52",
			"iso": "MX"
		},
		{
			"c_id": "143",
			"country_nm": "Micronesia",
			"c_phone_prefix": "691",
			"iso": "FM"
		},
		{
			"c_id": "144",
			"country_nm": "Moldova",
			"c_phone_prefix": "373",
			"iso": "MD"
		},
		{
			"c_id": "145",
			"country_nm": "Monaco",
			"c_phone_prefix": "377",
			"iso": "MC"
		},
		{
			"c_id": "146",
			"country_nm": "Mongolia",
			"c_phone_prefix": "976",
			"iso": "MN"
		},
		{
			"c_id": "147",
			"country_nm": "Montenegro",
			"c_phone_prefix": "381",
			"iso": "ME"
		},
		{
			"c_id": "148",
			"country_nm": "Montserrat",
			"c_phone_prefix": "+1-664",
			"iso": "MS"
		},
		{
			"c_id": "149",
			"country_nm": "Morocco",
			"c_phone_prefix": "212",
			"iso": "MA"
		},
		{
			"c_id": "150",
			"country_nm": "Mozambique",
			"c_phone_prefix": "258",
			"iso": "MZ"
		},
		{
			"c_id": "151",
			"country_nm": "Myanmar",
			"c_phone_prefix": "95",
			"iso": "MM"
		},
		{
			"c_id": "152",
			"country_nm": "Namibia",
			"c_phone_prefix": "264",
			"iso": "NA"
		},
		{
			"c_id": "153",
			"country_nm": "Nauru",
			"c_phone_prefix": "674",
			"iso": "NR"
		},
		{
			"c_id": "154",
			"country_nm": "Nepal",
			"c_phone_prefix": "977",
			"iso": "NP"
		},
		{
			"c_id": "155",
			"country_nm": "Netherlands",
			"c_phone_prefix": "31",
			"iso": "NL"
		},
		{
			"c_id": "156",
			"country_nm": "Netherlands Antilles",
			"c_phone_prefix": "599",
			"iso": "AN"
		},
		{
			"c_id": "157",
			"country_nm": "New Caledonia",
			"c_phone_prefix": "687",
			"iso": "NC"
		},
		{
			"c_id": "158",
			"country_nm": "New Zealand",
			"c_phone_prefix": "64",
			"iso": "NZ"
		},
		{
			"c_id": "159",
			"country_nm": "Nicaragua",
			"c_phone_prefix": "505",
			"iso": "NI"
		},
		{
			"c_id": "160",
			"country_nm": "Niger",
			"c_phone_prefix": "227",
			"iso": "NE"
		},
		{
			"c_id": "161",
			"country_nm": "Nigeria",
			"c_phone_prefix": "234",
			"iso": "NG"
		},
		{
			"c_id": "162",
			"country_nm": "Niue",
			"c_phone_prefix": "683",
			"iso": "NU"
		},
		{
			"c_id": "163",
			"country_nm": "Norfolk Island",
			"c_phone_prefix": "672",
			"iso": "NF"
		},
		{
			"c_id": "116",
			"country_nm": "North Korea",
			"c_phone_prefix": "850",
			"iso": "KP"
		},
		{
			"c_id": "164",
			"country_nm": "Northern Mariana Islands",
			"c_phone_prefix": "+1-670",
			"iso": "MP"
		},
		{
			"c_id": "165",
			"country_nm": "Norway",
			"c_phone_prefix": "47",
			"iso": "NO"
		},
		{
			"c_id": "166",
			"country_nm": "Oman",
			"c_phone_prefix": "968",
			"iso": "OM"
		},
		{
			"c_id": "167",
			"country_nm": "Pakistan",
			"c_phone_prefix": "92",
			"iso": "PK"
		},
		{
			"c_id": "168",
			"country_nm": "Palau",
			"c_phone_prefix": "680",
			"iso": "PW"
		},
		{
			"c_id": "169",
			"country_nm": "Palestinian Territory",
			"c_phone_prefix": "970",
			"iso": "PS"
		},
		{
			"c_id": "170",
			"country_nm": "Panama",
			"c_phone_prefix": "507",
			"iso": "PA"
		},
		{
			"c_id": "171",
			"country_nm": "Papua New Guinea",
			"c_phone_prefix": "675",
			"iso": "PG"
		},
		{
			"c_id": "172",
			"country_nm": "Paraguay",
			"c_phone_prefix": "595",
			"iso": "PY"
		},
		{
			"c_id": "173",
			"country_nm": "Peru",
			"c_phone_prefix": "51",
			"iso": "PE"
		},
		{
			"c_id": "174",
			"country_nm": "Philippines",
			"c_phone_prefix": "63",
			"iso": "PH"
		},
		{
			"c_id": "175",
			"country_nm": "Pitcairn",
			"c_phone_prefix": "+870",
			"iso": "PN"
		},
		{
			"c_id": "176",
			"country_nm": "Poland",
			"c_phone_prefix": "48",
			"iso": "PL"
		},
		{
			"c_id": "177",
			"country_nm": "Portugal",
			"c_phone_prefix": "351",
			"iso": "PT"
		},
		{
			"c_id": "178",
			"country_nm": "Puerto Rico",
			"c_phone_prefix": "+1-787 and 1-939",
			"iso": "PR"
		},
		{
			"c_id": "179",
			"country_nm": "Qatar",
			"c_phone_prefix": "974",
			"iso": "QA"
		},
		{
			"c_id": "50",
			"country_nm": "Republic of the Congo",
			"c_phone_prefix": "242",
			"iso": "CG"
		},
		{
			"c_id": "180",
			"country_nm": "Reunion",
			"c_phone_prefix": "262",
			"iso": "RE"
		},
		{
			"c_id": "181",
			"country_nm": "Romania",
			"c_phone_prefix": "40",
			"iso": "RO"
		},
		{
			"c_id": "182",
			"country_nm": "Russia",
			"c_phone_prefix": "7",
			"iso": "RU"
		},
		{
			"c_id": "183",
			"country_nm": "Rwanda",
			"c_phone_prefix": "250",
			"iso": "RW"
		},
		{
			"c_id": "652",
			"country_nm": "Saint Barth\u00e9lemy",
			"c_phone_prefix": "590",
			"iso": "BL"
		},
		{
			"c_id": "184",
			"country_nm": "Saint Helena",
			"c_phone_prefix": "290",
			"iso": "SH"
		},
		{
			"c_id": "185",
			"country_nm": "Saint Kitts and Nevis",
			"c_phone_prefix": "+1-869",
			"iso": "KN"
		},
		{
			"c_id": "186",
			"country_nm": "Saint Lucia",
			"c_phone_prefix": "+1-758",
			"iso": "LC"
		},
		{
			"c_id": "663",
			"country_nm": "Saint Martin",
			"c_phone_prefix": "590",
			"iso": "MF"
		},
		{
			"c_id": "187",
			"country_nm": "Saint Pierre and Miquelon",
			"c_phone_prefix": "508",
			"iso": "PM"
		},
		{
			"c_id": "188",
			"country_nm": "Saint Vincent and the Grenadines",
			"c_phone_prefix": "+1-784",
			"iso": "VC"
		},
		{
			"c_id": "189",
			"country_nm": "Samoa",
			"c_phone_prefix": "685",
			"iso": "WS"
		},
		{
			"c_id": "190",
			"country_nm": "San Marino",
			"c_phone_prefix": "378",
			"iso": "SM"
		},
		{
			"c_id": "191",
			"country_nm": "Sao Tome and Principe",
			"c_phone_prefix": "239",
			"iso": "ST"
		},
		{
			"c_id": "192",
			"country_nm": "Saudi Arabia",
			"c_phone_prefix": "966",
			"iso": "SA"
		},
		{
			"c_id": "193",
			"country_nm": "Senegal",
			"c_phone_prefix": "221",
			"iso": "SN"
		},
		{
			"c_id": "194",
			"country_nm": "Serbia",
			"c_phone_prefix": "381",
			"iso": "RS"
		},
		{
			"c_id": "891",
			"country_nm": "Serbia and Montenegro",
			"c_phone_prefix": "381",
			"iso": "CS"
		},
		{
			"c_id": "195",
			"country_nm": "Seychelles",
			"c_phone_prefix": "248",
			"iso": "SC"
		},
		{
			"c_id": "196",
			"country_nm": "Sierra Leone",
			"c_phone_prefix": "232",
			"iso": "SL"
		},
		{
			"c_id": "197",
			"country_nm": "Singapore",
			"c_phone_prefix": "65",
			"iso": "SG"
		},
		{
			"c_id": "198",
			"country_nm": "Slovakia",
			"c_phone_prefix": "421",
			"iso": "SK"
		},
		{
			"c_id": "199",
			"country_nm": "Slovenia",
			"c_phone_prefix": "386",
			"iso": "SI"
		},
		{
			"c_id": "200",
			"country_nm": "Solomon Islands",
			"c_phone_prefix": "677",
			"iso": "SB"
		},
		{
			"c_id": "201",
			"country_nm": "Somalia",
			"c_phone_prefix": "252",
			"iso": "SO"
		},
		{
			"c_id": "202",
			"country_nm": "South Africa",
			"c_phone_prefix": "27",
			"iso": "ZA"
		},
		{
			"c_id": "203",
			"country_nm": "South Georgia and the South Sandwich Islands",
			"c_phone_prefix": "+11",
			"iso": "GS"
		},
		{
			"c_id": "117",
			"country_nm": "South Korea",
			"c_phone_prefix": "82",
			"iso": "KR"
		},
		{
			"c_id": "204",
			"country_nm": "Spain",
			"c_phone_prefix": "34",
			"iso": "ES"
		},
		{
			"c_id": "205",
			"country_nm": "Sri Lanka",
			"c_phone_prefix": "94",
			"iso": "LK"
		},
		{
			"c_id": "206",
			"country_nm": "Sudan",
			"c_phone_prefix": "249",
			"iso": "SD"
		},
		{
			"c_id": "207",
			"country_nm": "Suriname",
			"c_phone_prefix": "597",
			"iso": "SR"
		},
		{
			"c_id": "208",
			"country_nm": "Svalbard and Jan Mayen",
			"c_phone_prefix": "47",
			"iso": "SJ"
		},
		{
			"c_id": "209",
			"country_nm": "Swaziland",
			"c_phone_prefix": "268",
			"iso": "SZ"
		},
		{
			"c_id": "210",
			"country_nm": "Sweden",
			"c_phone_prefix": "46",
			"iso": "SE"
		},
		{
			"c_id": "211",
			"country_nm": "Switzerland",
			"c_phone_prefix": "41",
			"iso": "CH"
		},
		{
			"c_id": "212",
			"country_nm": "Syria",
			"c_phone_prefix": "963",
			"iso": "SY"
		},
		{
			"c_id": "213",
			"country_nm": "Taiwan",
			"c_phone_prefix": "886",
			"iso": "TW"
		},
		{
			"c_id": "214",
			"country_nm": "Tajikistan",
			"c_phone_prefix": "992",
			"iso": "TJ"
		},
		{
			"c_id": "216",
			"country_nm": "Thailand",
			"c_phone_prefix": "66",
			"iso": "TH"
		},
		{
			"c_id": "218",
			"country_nm": "Togo",
			"c_phone_prefix": "228",
			"iso": "TG"
		},
		{
			"c_id": "219",
			"country_nm": "Tokelau",
			"c_phone_prefix": "690",
			"iso": "TK"
		},
		{
			"c_id": "220",
			"country_nm": "Tonga",
			"c_phone_prefix": "676",
			"iso": "TO"
		},
		{
			"c_id": "221",
			"country_nm": "Trinidad and Tobago",
			"c_phone_prefix": "+1-868",
			"iso": "TT"
		},
		{
			"c_id": "222",
			"country_nm": "Tunisia",
			"c_phone_prefix": "216",
			"iso": "TN"
		},
		{
			"c_id": "223",
			"country_nm": "Turkey",
			"c_phone_prefix": "90",
			"iso": "TR"
		},
		{
			"c_id": "224",
			"country_nm": "Turkmenistan",
			"c_phone_prefix": "993",
			"iso": "TM"
		},
		{
			"c_id": "225",
			"country_nm": "Turks and Caicos Islands",
			"c_phone_prefix": "+1-649",
			"iso": "TC"
		},
		{
			"c_id": "226",
			"country_nm": "Tuvalu",
			"c_phone_prefix": "688",
			"iso": "TV"
		},
		{
			"c_id": "239",
			"country_nm": "U.S. Virgin Islands",
			"c_phone_prefix": "+1-340",
			"iso": "VI"
		},
		{
			"c_id": "227",
			"country_nm": "Uganda",
			"c_phone_prefix": "256",
			"iso": "UG"
		},
		{
			"c_id": "228",
			"country_nm": "Ukraine",
			"c_phone_prefix": "380",
			"iso": "UA"
		},
		{
			"c_id": "229",
			"country_nm": "United Arab Emirates",
			"c_phone_prefix": "971",
			"iso": "AE"
		},
		{
			"c_id": "230",
			"country_nm": "United Kingdom",
			"c_phone_prefix": "44",
			"iso": "GB"
		},
		{
			"c_id": "215",
			"country_nm": "United Republic of Tanzania",
			"c_phone_prefix": "255",
			"iso": "TZ"
		},
		{
			"c_id": "231",
			"country_nm": "United States",
			"c_phone_prefix": "1",
			"iso": "US"
		},
		{
			"c_id": "232",
			"country_nm": "United States Minor Outlying Islands",
			"c_phone_prefix": "+1",
			"iso": "UM"
		},
		{
			"c_id": "233",
			"country_nm": "Uruguay",
			"c_phone_prefix": "598",
			"iso": "UY"
		},
		{
			"c_id": "234",
			"country_nm": "Uzbekistan",
			"c_phone_prefix": "998",
			"iso": "UZ"
		},
		{
			"c_id": "235",
			"country_nm": "Vanuatu",
			"c_phone_prefix": "678",
			"iso": "VU"
		},
		{
			"c_id": "96",
			"country_nm": "Vatican",
			"c_phone_prefix": "379",
			"iso": "VA"
		},
		{
			"c_id": "236",
			"country_nm": "Venezuela",
			"c_phone_prefix": "58",
			"iso": "VE"
		},
		{
			"c_id": "237",
			"country_nm": "Vietnam",
			"c_phone_prefix": "84",
			"iso": "VN"
		},
		{
			"c_id": "240",
			"country_nm": "Wallis and Futuna",
			"c_phone_prefix": "681",
			"iso": "WF"
		},
		{
			"c_id": "241",
			"country_nm": "Western Sahara",
			"c_phone_prefix": "212",
			"iso": "EH"
		},
		{
			"c_id": "242",
			"country_nm": "Yemen",
			"c_phone_prefix": "967",
			"iso": "YE"
		},
		{
			"c_id": "243",
			"country_nm": "Zambia",
			"c_phone_prefix": "260",
			"iso": "ZM"
		},
		{
			"c_id": "244",
			"country_nm": "Zimbabwe",
			"c_phone_prefix": "263",
			"iso": "ZW"
		}]
	};
   return countryIndustries;
}