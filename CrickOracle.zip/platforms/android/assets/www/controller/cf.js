/******************** likeUnlikePost  code  start **********************/
var CF = {
	index:'',




 	SendVerifyRequest: function(){
		successFlag = true;
		var yourself = $('#yourself').val().trim();
		var company = $('#Company').val().trim();
		if (company == ''){
	   		$('#Company').css('border','1px soild pink');
	   		successFlag = false;
	   		error_msg = "Please enter your Company";
	   		$('#Company').focus();
  		}

  		if (yourself == ''){
   			$('#yourself').css('border','1px soild pink');
   			successFlag = false;
   			error_msg = "Please enter yourself";
   			$('#yourself').focus();
  		}
 /*
  else if(yourself.length < 199){
    $('#yourself').css('border','1px soild pink');
    successFlag = false;
    error_msg = "Please enter max 200 characters yourself ";
    $('#yourself').focus();

  }*/

  		if (!successFlag){
   			MaraMentor.ShowAlert(error_msg);
   			return false;
  		}

  		var data = "content=" + yourself + "&company_name=" + company + "&user_id=" +MaraMentor.sessionId +"&func=requestForVerify";
  		MaraMentor.MakeAjaxCall(data, CF.SendVerifyRequestSuccess, CommonFailFunction);
 	},

 	SendVerifyRequestSuccess: function(result){
		var result = JSON.parse(result);
     	if (result.IsSuccess == 1) {
			MaraMentor.showToastMsg("Account verification request sent successfully. You will be notified shortly.");
			MaraMentor.HandleBack();
  		}
  		else{
   			MaraMentor.ShowAlert(result.Error);
  		}
 	},

	PostFollow: function(activity_id,type,index){
		CF.activity_id = typeof activity_id === 'undefined' ? 0 : parseInt(activity_id);
		CF.post_type = typeof type === 'undefined' ? 'follow' : type;
		CF.post_index = typeof index === 'undefined' ? 'null' : parseInt(index);
		if(CF.activity_id == 0 || CF.post_index == 'null')
			return false;
		//alert(CF.activity_id+","+CF.post_type+","+CF.post_index);
		var data = "activity_id=" + CF.activity_id + "&status=" + CF.post_type + "&user_id=" +MaraMentor.sessionId +"&func=activityFollow";
  		MaraMentor.MakeAjaxCall(data, CF.PostFollowSuccess, CommonFailFunction);

	},
	PostFollowSuccess: function(result){
		 var result = JSON.parse(result);

			if(result.IsSuccess){
				if(CF.post_type == "unfollow"){

					$("#follow_post_"+CF.activity_id).attr('onclick', 'CF.PostFollow( '+ CF.activity_id + ',' + '\'follow\'' + ',' + CF.post_index +' )');
					$("#follow_post_"+CF.activity_id).text("Follow");
					$("#follow_post_"+CF.activity_id).attr('title', "Follow");
				}
				else if(CF.post_type == "follow"){
					$("#follow_post_"+CF.activity_id).attr('onclick', 'CF.PostFollow( '+ CF.activity_id + ',' + '\'unfollow\'' + ',' + CF.post_index +' )');
					$("#follow_post_"+CF.activity_id).text("Unfollow");
					$("#follow_post_"+CF.activity_id).attr('title', "Unfollow");
				}

				if (TrendingManager.TrendingDataArray && TrendingManager.TrendingDataArray.length) {
					try{
						for( x in TrendingManager.TrendingDataArray) {
							if (parseInt(TrendingManager.TrendingDataArray[x]["activity_id"]) == parseInt( CF.activity_id ) ){
								TrendingManager.TrendingDataArray[x].post_follow = CF.post_type ==  "post_follow" ? 1 : 0;
								//TrendingManager.TrendingDataArray[x].like_count = total_likes;
								break;
							}
						}
					} catch(e) {}
				}

				if (ProfileManager.profile_activity && ProfileManager.profile_activity.length) {
					try{
						for( x in ProfileManager.profile_activity) {
							if (parseInt(ProfileManager.profile_activity[x]["activity_id"]) == parseInt( CF.activity_id ) ){
								ProfileManager.profile_activity[x].post_follow = CF.post_type ==  "post_follow" ? 1 : 0;
								//ProfileManager.profile_activity[x].like_count = total_likes;
								break;
							}
						}
					} catch(e) {}
				}
			}
			else{
				MaraMentor.showToastMsg("You are not following this Post");
			}
	},

	ReplaceTags: function( trendingContent ) {
		var textContent =  trendingContent;
		var imageContent = "";

		var x= trendingContent.search( '<div class="postedImage">' );
		if (x >= 0) {
			//trendingContent =  $('<div>'+trendingContent+'</div>').text();
			var textContent =  trendingContent.substring(0, x);
			var imageContent =  trendingContent.substring( x );
		}

		var HashTagRegEx = /(#\w+)/
		var atTagRegEx = /(@\w+)/

    	var urlHTTPRegEx = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
    	var urlWWWRegex = /(^|[^\/])(www\.[\S]+(\b|$))/gim;

		var hasAtTag = false;
   		/*if(atTagRegEx.test(DashManager.dashboardDataArray[d]["content"])){
			var el = $('<div>' + DashManager.dashboardDataArray[d]["content"] +'</div>');
			el.find('a').each(function(i) {
				if (parseInt($(this).attr("id")) == MaraMentor.sessionId){
				    $(this).replaceWith($(this).text());
				} else {
					if ($(this).attr("attag")){
						hasAtTag = true;
					    $(this).attr('onclick' , 'ProfileManager.Profile(' + $(this).attr("id") + ',1)');
					   if ($(this).attr('href')=="#")
					    $(this).attr('href' , 'changemebacktohash');
					}
				}
			});
			if (hasAtTag)
				dashboardContent = el.html();
		}*/

   		textContent = textContent.replace(/\B#(\w*[A-Za-z0-9]+\w*)/g, '<a href="#" onclick="SearchManager.SearchHtml(\'#$1\',1,\'trending\')">#$1</a>');
   		textContent = textContent.replace(/changemebacktohash/g, '#');
   		textContent = textContent.replace(/\\/g, '');


		trendingContent = CF.linkify(textContent) + imageContent;


   		if(HashTagRegEx.test(textContent) || atTagRegEx.test(textContent) || urlHTTPRegEx.test(textContent) || urlWWWRegex.test(textContent) )
        	is_found = true;
        else
        	is_found = false;

       return {
	        value: trendingContent,
	        is_found: is_found
    	};

	},

	linkify: function(inputText) {
	    var replacedText, replacePattern1, replacePattern2, replacePattern3;
	    //URLs starting with http://, https://, or ftp://
	    replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
	    //replacedText = inputText.replace(replacePattern1, '<a href="$1" target="_blank">$1</a>');
	    replacedText = inputText.replace(replacePattern1, '<a href=\'#\' onclick=\"openUrl(\'$1\')\">$1</a>');
	    //URLs starting with "www." (without // before it, or it'd re-link the ones done above).
	    replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
	    //replacedText = replacedText.replace(replacePattern2, '$1<a href="http://$2" target="_blank">$2</a>');
	    replacedText = replacedText.replace(replacePattern2, '$1<a href=\"#\"  onclick=\"openUrl(\'http://$2\')\">$2</a>');
	    //Change email addresses to mailto:: links.
        //replacePattern3 = /(([a-zA-Z0-9\-\_\.])+@[a-zA-Z\_]+?(\.[a-zA-Z]{2,6})+)/gim;
	    //replacedText = replacedText.replace(replacePattern3, '<a href="mailto:$1">$1</a>');
	    return replacedText;
	},

	OnFocusCountryField: function() {
		CF.Xcc = $('#countrycode').val();
        return true;
	},

	OnBlurCountryField: function() {
		var cc = $('#countrycode').val();

		if (!CF.Xcc){
			$('#countrytext').val("");
			return true;
		}

		for (var c = 0; c < MaraMentor.country_array.length; c++) {
        	if (cc && cc == MaraMentor.country_array[c]['phone_prefix'] && $('#countrytext').val() != MaraMentor.country_array[c]['country'] + " (+" + MaraMentor.country_array[c]['phone_prefix'] + ")"){
        		$('#countrytext').val(MaraMentor.country_array[c]['country'] + " (+" + MaraMentor.country_array[c]['phone_prefix'] + ")")
        		break;
        	}
        }
        return true;
	}

}
