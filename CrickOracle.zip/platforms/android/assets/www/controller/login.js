//Login Manager
var LoginManager = {
	currentPage:1,
	signUpHTMLStep1:"",
	signUpHTMLStep2:"",
	txtGender:"",
	txtCompanyAc:"NO",
	ForgotPassId:0,
	TermsError:false,
    Login: function(){
    	MaraMentor.currentScreen = 'login';
    	LoginManager.txtGender = "";
      	MaraMentor.MakeAjaxCallHTML("views/login.html", LoginManager.LoginHtmlSuccess, CommonFailFunction);
   	},

    LoginHtmlSuccess: function (result) {
		MaraMentor.backPages.length=0;
    	MaraMentor.ChangeHeaderText("Login");
    	MaraMentor.PushPageRecord("welcome");
    	MaraMentor.PushPageRecord("login");

    	//MaraMentor.ShowHeader();
    	MaraMentor.ChangePageContent(result);

    	MaraMentor.SetupCountriesAutocomplete(MaraMentor.lastLoggedInCountry);
		$('#phone').val(MaraMentor.lastLoggedInMobile);
		$('#wrapper').addClass('black-bg');
		MaraMentor.RemoveScrollBar();
				//GaganChanges

		/*Native Code*/
	    if(platform=="iOS"){
			MaraMentor.RefreshScrollBar();
		//MaraMentor.RemoveScrollBar();
		$('body').height(deviceHeight+"px");
		}
	},

    LoginUser: function(){
  		//var username = $('#username');
  		var phone = $('#phone');
		var countrycode = $("#countrycode").val();
		var countrytext = $("#countrytext");
  		var password = $('#password');
  		var req_data = "";
  		successFlag = true;

  		if (countrycode == ''){
			countrytext.css('border','1px soild pink');
			req_data += req_data=="" ? "Country" : ", Country" ;
			successFlag = false;
		}

		if (phone.val().trim() == ''){
			req_data += req_data=="" ? "Mobile Number" : ", Mobile Number" ;
			phone.css('border','1px soild pink');
			successFlag = false;
			phone.focus();
		}

		if (password.val().trim() == ''){
			req_data += req_data=="" ? "Password " : ", Password" ;
			password.css('border','1px soild pink');
			successFlag = false;
		}

		if (!successFlag){
			MaraMentor.showToastMsg('Please enter '+req_data+' to continue.');
			return false;
		}

		var data = "country_prefix=" + countrycode + "&username=" + phone.val()+ "&password=" + password.val() + "&func=login";
		//var data = "username=" + username.val() + "&password=" + password.val() + "&func=login";
        MaraMentor.MakeAjaxCall(data, LoginManager.LoginUserSuccess, CommonFailFunction);
   	},

    LoginUserSuccess: function (result) {

    	 var result = JSON.parse(result);

    	 if (result.IsSuccess){
    	 	AnalyticalManager.Tag("Login");
    	 	MaraMentor.user_id = parseInt(result.data.user_id);

			if(parseInt(result.data.status) == 0){
	    	 	MaraMentor.sessionId = parseInt(result.data.user_id);
	    	 	MaraMentor.userName = result.data.display_name;
	    	 	MaraMentor.userImage = result.data.user_image;
	    	 	MaraMentor.userIndustry = result.data.industry;
	    		MaraMentor.lastLoggedInCountry = $("#countrycode").val();
	    		MaraMentor.lastLoggedInMobile = $('#phone').val();


	    	 	try {
		    		window.localStorage.setItem("lastLoggedInCountry", MaraMentor.lastLoggedInCountry);
		    		window.localStorage.setItem("lastLoggedInMobile", MaraMentor.lastLoggedInMobile );
				} catch (e) {}

				MaraMentor.LoginSuccess();
			} else if(parseInt(result.data.status) == 2){
				MaraMentor.userKey = result.data.key;
				MaraMentor.MakeAjaxCallHTML("views/sign_up.html", LoginManager.VerifyHtmlSuccess, CommonFailFunction);
			}
    	  	//EditProfileManager.EditProfile()
    	 }
    	 else
    	 {
    	 	//alert(result.data+"test");
	    	MaraMentor.ShowAlert(result.data);
			return false;
    	 }
    },

	VerifyHtmlSuccess: function(result){

		step1 = $(result).filter("#step1");
		LoginManager.signUpHTMLStep1 = step1.html();
		step2 = $(result).filter("#step2");
		LoginManager.signUpHTMLStep2 = step2.html();
		verify = $(result).filter("#verify");
		LoginManager.signUpHTMLVerify = verify.html();
		MaraMentor.ChangePageContent(LoginManager.signUpHTMLVerify);

	},
	SetupSignUpCountryIndustr: function () {
        var mCountries = [];
        for (var c = 0; c < MaraMentor.mentor_country_arr.length; c++) {
            mCountries[c] = {
                id: MaraMentor.mentor_country_arr[c]['c_phone_prefix'],
                title: MaraMentor.mentor_country_arr[c]['country_nm'] + " (+" + MaraMentor.mentor_country_arr[c]['c_phone_prefix'] + ")"
            };
        }

        $('#sCountrytext').tinyAutocomplete({
            data: mCountries,
            onEscape: function (val) {
                //  alert(val);
            },
            onSelect: function (el, val) {
                if (val == null) {
                    $(this).focus();
                } else {
                    $("#sCountrycode").val(val.id);
                    $(this).val(val.title);
                }
            }
        });

        var mCountryCode = "";
        var mountryText = "";

        for (var c = 0; c < MaraMentor.mentor_country_arr.length; c++) {
            if(MaraMentor.mentor_country_arr[c]['iso'].toLowerCase()== MaraMentor.countryIsoCode.toLowerCase()){
                countryCode= MaraMentor.mentor_country_arr[c]['country_nm'];
                countryText= MaraMentor.mentor_country_arr[c]['country_nm'];

                mCountryCode= MaraMentor.mentor_country_arr[c]['c_phone_prefix'];
                mCountryText= MaraMentor.mentor_country_arr[c]['country_nm'] + " (+" + MaraMentor.mentor_country_arr[c]['c_phone_prefix'] + ")";
            }
        }


        if(mCountryCode!="" && mCountryText !="" && mCountryText!=undefined && mCountryCode != undefined){
            $("#sCountrycode").val(mCountryCode);
            $("#sCountrytext").val(mCountryText);
        }
    },
    SignUp: function(){
    	MaraMentor.currentScreen = "signup";
      	MaraMentor.MakeAjaxCallHTML("views/sign_up.html", LoginManager.SignUpHtmlSuccess, CommonFailFunction);
   	},

	SignUpHtmlSuccess: function (result) {
		LoginManager.currentPage =1;
		MaraMentor.backPages.length=0;
    	MaraMentor.PushPageRecord("welcome");
    	MaraMentor.PushPageRecord("login");

    	MaraMentor.ChangeHeaderText("Sign Up");
    	LoginManager.txtGender = '';
    	LoginManager.txtCompanyAc = 'NO';
    	LoginManager.signUpHTML = $(result).html();
		/*step1 = $(result).filter("#step1");
		LoginManager.signUpHTMLStep1 = step1.html();
		step2 = $(result).filter("#step2");
		LoginManager.signUpHTMLStep2 = step2.html();
		verify = $(result).filter("#verify");
		LoginManager.signUpHTMLVerify = verify.html();*/

    	MaraMentor.ChangePageContent(LoginManager.signUpHTML);
    	MaraMentor.SetupCountriesAutocomplete(MaraMentor.lastLoggedInCountry);
		MaraMentor.RemoveScrollBar();

		//GaganChanges
		if(platform=="iOS"){
		MaraMentor.RefreshScrollBar();
		$('body').height(deviceHeight+"px");
		setTimeout(function() {  //calls click event after a certain time
			if(platform=="iOS")
				RefreshScrollBar();
		}, 1000);
		}
		//MaraMentor.RemoveScrollBar();
	},

	HandlePreviousNextSteps:function(type){
        $("body").css("background","white");
        //$("#wrapper").height("90%");
        var previousPage= LoginManager.currentPage;
        
        if(type=="next"){
            LoginManager.currentPage+=1;
        }
        if(type=="previous"){
            LoginManager.currentPage-=1;
        }
        $('#step'+previousPage).animate(
        	{ opacity: 0 },
        	300,
        	'linear',
        	function() {
        			$('#step'+previousPage).hide();
        			$('#step'+LoginManager.currentPage).show().css("opacity","1");
        			//myScroll.scrollTo(0,0,0);
				    MaraMentor.RefreshScrollBar();
        	}
        );
        //Last or first condition
        if(LoginManager.currentPage ==5 || LoginManager.currentPage ==1 ){
            MaraMentor.PushPageRecord('welcomeLogin');
            MaraMentor.PushPageRecord('signUpSteps');
            MaraMentor.ChangeHeaderText("Sign Up");
        }
    },
    SignUpUser: function(){
    	var phone = $('#phone');
    	var username = $('#username');
  		var password = $('#password');
  		var gender = $('#gender');
  		var countrycode = $("#countrycode").val();
  		var countrytext = $("#countrytext");
  		var comp_account = $("#comp_account").val();
  		//var terms = $("#term");
  		 var terms =  document.getElementById("terms");
		var req_data = "";

  		successFlag = true;

		if (countrycode == ''){
			countrytext.css('border','1px soild pink');
			req_data += "Country Name";
			successFlag = false;
		}

		if (phone.val().trim() == ''){
			phone.css('border','1px soild pink');
			req_data += req_data=="" ? "Mobile Number" : ", Mobile Number" ;
			successFlag = false;
			phone.focus();
		}

		if (username.val().trim() == ''){
			username.css('border','1px soild pink');
			req_data += req_data=="" ? "Username" : ", Username" ;
			successFlag = false;
			username.focus();
		}

		if (password.val().trim() == ''){
			password.css('border','1px soild pink');
			req_data += req_data=="" ? "Password" : ", Password" ;
			successFlag = false;
			password.focus();
		}
		else if ((password.val().length <6) || (password.val().length > 15)){
			password.css('border','1px soild pink');
			req_data += req_data=="" ? "Passwored length should be 6-15 characters" : ", Passwored length should be 6-15 characters" ;
			successFlag = false;
			password.focus();
		}

		if (LoginManager.txtGender == '' && LoginManager.txtCompanyAc == "NO"){
			$(".genderText").css('border','1px soild pink')
			successFlag = false;
			req_data += req_data=="" ? "Gender" : ", Gender" ;
		}

		if(LoginManager.txtCompanyAc == "YES")
			LoginManager.txtGender = '';

		if (LoginManager.txtCompanyAc == ''){
			$("#comp_account1").css('border','1px soild pink')
			req_data += req_data=="" ? "Account Type" : ", Account Type" ;
			successFlag = false;
		}
		//term code start here

		 if (!terms.checked) {
		 	$("#term").css('border','1px soild pink')
		 	req_data += req_data=="" ? "accept terms of use" : ", accept terms of use" ;
		 	LoginManager.TermsError = true;
			successFlag = false;
        }


		//end

		if (!successFlag){
			MaraMentor.showToastMsg('Please fill required information : '+req_data);
			return false;
		}

		var data =  "countrycode=" + countrycode + "&phone=" + phone.val() + "&username=" + username.val() + "&password=" + password.val() +"&gender=" + LoginManager.txtGender +"&comp_account="+LoginManager.txtCompanyAc+ "&func=signup";
        MaraMentor.MakeAjaxCall(data, LoginManager.SignUpUserSuccess, CommonFailFunction);
	},

	SignUpUserSuccess: function (result) {
		AnalyticalManager.Tag("SignUp New User");

		var result = JSON.parse(result);
		if (result.IsSuccess)
		{
			MaraMentor.user_id = result.user_id;
			//MaraMentor.userName = result.display_name;
			MaraMentor.userKey = result.key;
			//MaraMentor.userKey = "123456";
			MaraMentor.ChangePageContent(LoginManager.signUpHTMLVerify);
			//MaraMentor.ChangePageContent(LoginManager.signUpHTMLStep2);
			MaraMentor.RemoveScrollBar();
			//GaganChanges
			if(platform=="iOS"){
				MaraMentor.RefreshScrollBar();
		}
		} else {
			MaraMentor.ShowAlert(result.Error);
		}

    },
	UserVerify: function(){
		var verify = $('#verify_id');
		var verify_val = verify.val().trim();
		var msg = "Please enter verify code.";
		var successFlag = true;
		if (verify_val == ''){
				verify.css('border','1px soild pink');
				successFlag = false;
				verify.focus();
			}
		else if (!(verify_val == MaraMentor.userKey)){
			verify.css('border','1px soild pink');
			successFlag = false;
			msg = "Please check your verify code!";
			verify.focus();
		}
		if (!successFlag){
			MaraMentor.ShowAlert(msg);
			return false;
		}
		//LoginManager.ssUserVerifySuccess(1);
		var data =  "user_id=" + MaraMentor.user_id + "&code=" + verify_val + "&func=mobileVerification";
        MaraMentor.MakeAjaxCall(data, LoginManager.UserVerifySuccess, CommonFailFunction);
	},
	UserVerifySuccess: function (result) {
		var result = JSON.parse(result);

		if (result.IsSuccess)
		{
		   	//MaraMentor.ChangeHeaderText("Login");
		   	MaraMentor.ChangeHeaderText("Mara Trends");

    	 	MaraMentor.sessionId = parseInt(result.data.user_id);
    	 	MaraMentor.userName = result.data.display_name;
    	 	MaraMentor.userImage = result.data.user_image;
    	 	MaraMentor.userIndustry = result.data.industry;
    		MaraMentor.lastLoggedInCountry = $("#countrycode").val();
    		MaraMentor.lastLoggedInMobile = $('#phone').val();

    	 	try {
	    		window.localStorage.setItem("lastLoggedInCountry", MaraMentor.lastLoggedInCountry);
	    		window.localStorage.setItem("lastLoggedInMobile", MaraMentor.lastLoggedInMobile );
	    		window.localStorage.setItem( "sessionId" , MaraMentor.sessionId);
				window.localStorage.setItem( "userName" , MaraMentor.userName);
			} catch (e) {}

			$(".headingHeader").css("visibility","hidden");
			MaraMentor.ChangePageContent(LoginManager.signUpHTMLStep2);

			$('#wrapper').addClass('black-bg');

			PushNotificationManger.Initilize();

			MaraMentor.RemoveScrollBar();
		} else {
			MaraMentor.ShowAlert(result.Error);
		}

    },
	OnclickMaleFemale: function (current_selected) {
		if (current_selected=="male"){
			LoginManager.txtGender ="Male";
			$('#male img').attr('src', 'assets/images/male.png');
			$('#female img').attr('src', 'assets/images/female_grey.png');
		} else {
			LoginManager.txtGender ="Female";
			 $('#female img').attr('src', 'assets/images/female.png');
			 $('#male img').attr('src', 'assets/images/male_grey.png');
		}

		$(".genderText").text(LoginManager.txtGender);

	},

	OnclickCompanyYesNo: function () {
		LoginManager.txtCompanyAc = LoginManager.txtCompanyAc=="YES" ? "NO" : "YES";
		$("#comp_account").html(LoginManager.txtCompanyAc);
		if(LoginManager.txtCompanyAc == "YES")
			$(".gender").hide();
		else
			$(".gender").show();

	},

	ForgotPassword: function(){
    	MaraMentor.MakeAjaxCallHTML("views/forget_password.html", LoginManager.ForgotPasswordHtmlSuccess, CommonFailFunction);
  	},

  	ForgotPasswordHtmlSuccess: function(result){
     	MaraMentor.PushPageRecord("forgotpassword");
    	MaraMentor.ChangeHeaderText("Forgot Password");

      	MaraMentor.ChangePageContent(result);
    	MaraMentor.RemoveScrollBar();
      	MaraMentor.SetupCountriesAutocomplete();
  	},

  	ForgotPassChange: function(){
    	var flag = true;
  		var countrycode = $('#countrycode').val();
    	var mobile = $('#phone').val();
    	if (mobile == '') {
	   		errormsg = "Please don't leave required(*) field empty.";
	   		$('.loginOption input').css('border','1px soild pink');
	   		flag = false;
	  	} else if (isNaN(mobile) || mobile.indexOf(" ") != -1) {
            errormsg = "Please enter numeric value in mobile field.";
            $('.loginOption input').css('border','1px soild pink');
            flag = false;
        } else if ((mobile.length < 7) || (mobile.length > 15)) {
            errormsg = "Please enter valid mobile no.";
            $('.loginOption input').css('border','1px soild pink');
            flag = false;
        } else {
            $(".loginOption input").css('border', '');
        }
        if (countrycode == ''){
   			countrytext.css('border','1px soild pink');
   			flag = false;
  		}

    	if (!flag)
	    {
	      MaraMentor.showToastMsg(errormsg);
	      return false;
	  	}
		LoginManager.forgotlogin = countrycode+"-"+mobile;
   			var data = "code=" + countrycode + "&phone=" + mobile + "&func=forgot_Password";
   			MaraMentor.MakeAjaxCall(data, LoginManager.ForgotPassChangeSuccess, LoginManager.CommonFailFunction);

  	},

  	ForgotPassChangeSuccess: function(result){
	   	var result = JSON.parse(result);
	   	if (result.IsSuceess == 1) {
			LoginManager.ForgotPassId = result.user_id;
	        document.getElementById('mainDiv2').style.display='block';
	        //document.getElementById('mainDiv2').style.='block';
	        document.getElementById('mainDiv1').style.display='none';
	      //  alert("Your verify code is : "+result.verifi);
	     }
	     else
	     {
	        document.getElementById('mainDiv2').style.display='none';
	        document.getElementById('mainDiv1').style.display='block';
	      	MaraMentor.showToastMsg("Invalid mobile number");
	     }
  	},
	ChangePasswordHtml: function(){
		MaraMentor.MakeAjaxCallHTML("views/forget_change_password.html", LoginManager.ChangePasswordHtmlSuccess, CommonFailFunction);
	//LoginManager.forgotlogin;
	},
	ChangePasswordHtmlSuccess: function(result){
		//MaraMentor.PushPageRecord("forgotpassword");
    	MaraMentor.ChangeHeaderText("Password Change");
      	MaraMentor.ChangePageContent(result);
    	//MaraMentor.RemoveScrollBar();
		MaraMentor.RefreshScrollBar();
      	MaraMentor.SetupCountriesAutocomplete();
	},
	ChangePasswordWithcode: function(){
    	var verify_code = $('#verify_code');
    	var password_conform = $('#change_password_confirm');
  		var password = $('#change_password');
  		successFlag = true;
		var error_msg = "Please enter data";

		if (verify_code.val().trim() == ''){
			verify_code.css('border','1px soild pink');
			successFlag = false;
			error_msg = "Please enter verify code";
			verify_code.focus();

		}
		else if (password.val().trim() == ''){
			password.css('border','1px soild pink');
			successFlag = false;
			error_msg = "Please enter password";
			password.focus();
		}
		else if ((password.val().length <6) || (password.val().length > 15)){
			password.css('border','1px soild pink');
			error_msg = "Passwored length should be 6-15 characters" ;
			successFlag = false;
			password.focus();
		}
		else if (password_conform.val().trim() == ''){
			password_conform.css('border','1px soild pink');
			successFlag = false;
			error_msg = "Please enter confirm password";
			password_conform.focus();
		}

		else if(password.val() != password_conform.val()){
			error_msg = "Confirm password not match with password!";
			successFlag = false;
			password_conform.focus();
		}

		if (!successFlag){
			MaraMentor.ShowAlert(error_msg);
			return false;
		}
		if(!LoginManager.ForgotPassId)
			return false;
		var data =  "user_id=" + LoginManager.ForgotPassId + "&code=" + verify_code.val() + "&user_pass=" + password.val() + "&func=setUserNewPassword";
        MaraMentor.MakeAjaxCall(data, LoginManager.ChangePasswordWithcodeSuccess, CommonFailFunction);
	},

	ChangePasswordWithcodeSuccess: function(result){
		AnalyticalManager.Tag("Password Change");

		var result = JSON.parse(result);

		MaraMentor.ShowAlert(result.data);

	   	if (result.IsSuccess == 1)
			LoginManager.Login();
	},
	NewVerifCode: function(){

		var data =  "user_id=" + MaraMentor.user_id + "&func=newVerifyCode";
        MaraMentor.MakeAjaxCall(data, LoginManager.NewVerifCodeSuccess, CommonFailFunction);
	},
	NewVerifCodeSuccess: function(result){
		var result = JSON.parse(result);
		if (result.IsSuccess == 1)
			MaraMentor.userKey = result.data.key;
		else
			MaraMentor.ShowAlert(result.Error);
	},
	NewVerifCode2: function(){
		if(!LoginManager.ForgotPassId)
			return false;
		var data =  "user_id=" + LoginManager.ForgotPassId + "&func=newForgotPasswordCode";
        MaraMentor.MakeAjaxCall(data, LoginManager.NewVerifCodeSuccess2, CommonFailFunction);
	},
	NewVerifCodeSuccess2: function(result){
		var result = JSON.parse(result);
		if (result.IsSuccess == 1){
			//alert("result");
			//MaraMentor.userKey = result.data.key;
		}
		else{
			MaraMentor.ShowAlert("Verification Code not successfully send try again!");
		}
	},
	sendVoiceCall: function () {

		var data =  "user_id=" + MaraMentor.user_id + "&func=VoiceUserKey";
        MaraMentor.MakeAjaxCall(data, LoginManager.sendVoiceCallSuccessFunction, CommonFailFunction);
    },
    sendVoiceCallSuccessFunction: function (arg) {
    },
    SetStaticHTML: function (PageName) {
        LoginManager.pageName = PageName;
        var data =  "page_type=" +PageName + "&func=getStaticPages";
        MaraMentor.MakeAjaxCall(data, LoginManager.SetStaticHTMLSuccess, CommonFailFunction);

    },
    SetStaticHTMLSuccess: function (resultData) {
        var myPage = JSON.parse(resultData);
        if (myPage.IsSuccess == 1) {
        	MaraMentor.isTermPage = true;
          //  MaraMentor.ChangeHeaderText("Terms and conditions");
            $('#forumdata').hide();
            $('#termData').show();
            $('#termData').html("<div style='color:#fff;'>"+myPage.data.pageTitle+"</div><div style='color:#fff;'>"+myPage.data.page_des+"</div>");
           // MaraMentor.RefreshScrollBar();
        }
    },
}

