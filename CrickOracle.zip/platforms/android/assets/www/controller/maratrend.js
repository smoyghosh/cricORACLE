﻿var platform = 'ANDROID';
//var platform = 'iOS';

var debug = true;
var	myScroll = null;
var menuScroll = null;
var pulseInterval = null;
var menuScrollAttached =false;
var image_upload_quality = 95;
var sideMenuHeight = 1000;
var apiKey = '12365465';
var pushNotification = null;
var push_career="";
//var serverURL = 'http://192.168.1.99/maratrend/mobile-api/api-handler.php';
var serverURL = 'https://maratrendapp.mara.com/mobile-api/api-handler.php';
//var serverURL = 'https://trends.mara.com/mobile-api/api-handler.php';
var gravatarImage = "assets/images/mystery-man.jpg"
var refreshCounter = 0;

//GaganChanges
var deviceHeight = 0;
var deviceHeight2 =0;

function ShowHide(i) {
    document.getElementById('divtab2').style.display = 'none';
    document.getElementById('loginEmail').style.display = 'none';
    if (i==1){
        document.getElementById('loginEmail').style.display = 'block';
        document.getElementById('mobile').style.display = 'none';
        document.getElementById('divtab2').style.display = 'block';
        document.getElementById('divtab1').style.display = 'none';
    }
    if (i==2){
        document.getElementById('loginEmail').style.display = 'none';
        document.getElementById('mobile').style.display = 'block';
        document.getElementById('divtab1').style.display = 'block';
        document.getElementById('divtab2').style.display = 'none';
    }
}



$(document).ready(function () {
	myScroll = null;
   var width = $(window).width();
   var height = $(window).height();
 //GaganChanges
   deviceHeight2 = height;

   if(width < 500 ){
   size = width*4/100;
   }
   else if(width > 500 ){
   size = width*2.5/100;
  }

  	$('body').css("font-size",size+"px").height(height+"px");
    MaraMentor.Initialize();

   if (!menuScrollAttached ){
	  $('#menu_scroller .scroller').css("height",sideMenuHeight + "px");
	  $('#menu_scroller .scroller').css("width","100%");
		menuScroll = new iScroll('menu_scroller', { hScrollbar: false });
		menuScrollAttached = true;
		MaraMentor.RefreshMenuScrollBar();
	}

});

last_click_time = new Date().getTime();
document.addEventListener('click', function (e) {
    click_time = e['timeStamp'];
    if (click_time && (click_time - last_click_time) < 1000) {
        e.stopImmediatePropagation();
        e.preventDefault();
        return false;
    }
    last_click_time = click_time;
},true);

//Any failure request common landing function
function CommonFailFunction(res){
	/* Intensinally left blank */
  	MaraMentor.HideLoader();
    MaraMentor.ShowAlert("Sorry, we​ could not process your request now.​ Please try again later.");

}

//Common function to Dashboard/Trending
function fnTrending( filter ){
	/*Native Code*/
    if(platform=="iOS"){
		MaraMentor.isSideMenuShown=false;
	}
	TrendingManager.filter = typeof filter === "undefined" ? "" :  filter;
	TrendingManager.Trending();
}

function onExitConfirm(button) {
    if(button==2){//If User selected No, then we just do nothing
        return;
    }else{
        navigator.app.exitApp();// Otherwise we quit the app.
    }
}

function alertDismissed() {
    // do something
}

function mobilecheck() {
	var check = false;
	(function(a){if(/(android|ipad|playbook|silk|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))check = true})(navigator.userAgent||navigator.vendor||window.opera);
	return check;
}

function hasParentClass( e, classname ) {
	if(e === document) return false;
	if( classie.has( e, classname ) ) {
		return true;
	}
	return e.parentNode && hasParentClass( e.parentNode, classname );
}

function bindKeyboardEvents() {
  document.addEventListener("showkeyboard", function() {
        focusedElement = $(document.activeElement);
        elementTagName = document.activeElement.tagName;
		$("#header").css("margin-top","0px");
		if(elementTagName=="INPUT"){
                MaraMentor.RefreshScrollBar();
                setTimeout(function() {
                    myScroll.scrollToElement(focusedElement, 100);
                }, 100);
        }
    }, false);
    document.addEventListener("hidekeyboard", function() {
		$("#header").css("margin-top","0px");

		if (MaraMentor.currentScreen == "welcome"){
			 setTimeout(function() {
					$("#header").css("margin-top","0px");
			    	MaraMentor.WelcomeScreen();
                }, 200);
      } else {
      	if (MaraMentor.currentScreen=="signup"){
            MaraMentor.RefreshScrollBar();
         }else{
	      	 setTimeout(function() {
	            MaraMentor.RefreshScrollBar();
	            myScroll.refresh();
	        }, 100);
        }
      }
    }, false);
}

function openUrl(url, elem) {
   window.open(url, '_blank', 'location=yes');
}

function checkIfNullorUndefined(arg){
	 if(arg == undefined || arg == "undefined" || arg ==null || arg == "null" )
	  	return true;
	 else
	  	return false;
}

function bindSideMenu() {
//			alert("inside init");
	var container = document.getElementById( 'st-container' ),
		buttons = Array.prototype.slice.call( document.querySelectorAll( '#st-trigger-effects > button' ) ),
		// event type (if mobile use touch events)
		eventtype = mobilecheck() ? 'touchstart' : 'click',
		resetMenu = function() {
				$("#st-container").removeClass("st-menu-open"); 	//Added by RANA
			setTimeout(function() {
				if (myScroll!=null)
					MaraMentor.RefreshScrollBar();						//Added by RANA
			},400);
		},
		//Close Sidebar
		bodyClickFn = function(evt) {
			if( !hasParentClass( evt.target, 'st-menu' ) ) {
				resetMenu();
				document.removeEventListener( eventtype, bodyClickFn );
				setTimeout(function() {
					$('.st-menu ul').scrollTop(0);
				}, 50);
			}
		};

	//Open Sidebar
	buttons.forEach( function( el, i ) {
		var effect = el.getAttribute( 'data-effect' );

		el.addEventListener( eventtype, function( ev ) {
			//Added by Rana
			if ($("#st-container").hasClass("st-menu-open")){
				$("#st-container").removeClass("st-menu-open"); 	//Added by RANA
    			setTimeout(function() {
						MaraMentor.RefreshScrollBar();						//Added by RANA
						MaraMentor.RefreshMenuScrollBar();
					myScroll.scrollTo(0,0,0);
				},400);

    			return ;
    		}
//				alert("inside event listener");
			ev.stopPropagation();
			ev.preventDefault();
			container.className = 'st-container'; // clear
			classie.add( container, effect );

			MaraMentor.RefreshScrollBar();									//Added by RANA

			if (!$("#st-container").hasClass("st-menu-open")){
    			$("#st-container").addClass("st-menu-open");
    			menuScroll.scrollTo(0,0,0);
    			//myScroll.scrollTo(0,0,0);
    		}
			document.addEventListener( eventtype, bodyClickFn );
		});
	} );

}

function Logout(){
		AnalyticalManager.Tag("Logout");

    	MaraMentor.HideSideBar();

		try{
			window.localStorage.removeItem( "sessionId" );
			window.localStorage.removeItem( "userName" );
			window.localStorage.removeItem( "userIndustry" );
//    		window.localStorage.removeItem( "lastLoggedInCountry" );
  //  		window.localStorage.removeItem( "lastLoggedInMobile" );
		} catch(e) { }

		MaraMentor.sessionId = 0;
		MaraMentor.isLogin = false;
		MaraMentor.backPages.length = 0;
		NotificationManager.userNotification=0;
//		MaraMentor.lastLoggedInCountry ="";
//		MaraMentor.lastLoggedInMobile = "";
		MaraMentor.WelcomeScreen();
}


var MaraMentor = {
	IsLoadMore:"false",
	isTermPage:false,
	isDemoScreen:false,
	demoScreenNo:1,
	backPages: [],
	lastImageUrl:"",
	savedSessionId: "",
	isLogin:false,
	isCountrySetup:false,
	isAjaxCall:false,
	isAjaxAlertBoxShowing:false,
	sessionId:0,
	countryIsoCode:"",
	lastLoggedInMobile:"",
	userName:"",
	userImage:"",
	userIndustry:"",
	verify_status:"",
	navBar:"",
	isSideMenuShown:false,
    loading_div:'<div class="upDation loadingdiv" id="loadingdiv" style="overflow:hidden;height: 20px; text-align: -webkit-center;vertical-align: -webkit-baseline-middle;font-size: 1.2em;font-weight: bolder;" data-transition="slide"><span id="loading_text">Refreshing...</span><div class="clear">',
	Initialize: function () {
    	debug = !mobilecheck();
        this.bindEvents();
    },

    // Bind Event Listeners
    bindEvents: function () {

		/*clearInterval(pulseInterval);
        if (pulseInterval==null)
        	pulseInterval = setInterval(function(){
        		MaraMentor.PulseGenerator();
        	},15000);*/

        MaraMentor.GetAllCountries();
    	document.addEventListener('deviceready', this.onDeviceReady, false);
 		bindSideMenu();
 		bindKeyboardEvents();

        if (debug) MaraMentor.onDeviceReady();
    },

    onDeviceReady: function () {
		//if (!eventListener_backbutton) {
    	  document.addEventListener("backbutton", MaraMentor.HandleBack, false);
    	  //eventListener_backbutton = true;
    	//}
    	/*Native Code*/
    	if(platform=="iOS"){
    		//alert(window.innerHeight);

    		//GaganChanges
    		//navigator.splashscreen.hide();
			$("#header").css("display","none");
			MaraMentor.SetupHeaderFooterNavigation();
       		MaraMentor.navBar.hide();
       		$("#header").hide();
       		MaraMentor.isSideMenuShown=false;
       			if(device.version>6)
       			  deviceHeight = window.innerHeight-64;
       			else
       			  deviceHeight = window.innerHeight-44;

       			$('body').height(deviceHeight+"px");
       		}
       		/*Native Code*/

    	this.savedSessionId = window.localStorage.getItem("sessionId");

    	if (!debug){
	        /*var telephoneNumber = cordova.require("cordova/plugin/telephonenumber");
	        telephoneNumber.get(function(result) {
	                MaraMentor.countryIsoCode= result;
	            }, function() {
	        });

	        telephoneNumber.getMobileNo(function(result) {
	        		MaraMentor.lastLoggedInMobile = result;
	            }, function() {
	        });*/
		 }

    	if (this.savedSessionId != null && this.savedSessionId != "") {
    		MaraMentor.sessionId = parseInt(this.savedSessionId);
    		if (!MaraMentor.sessionId)
 		   		Logout();

			//PushNotificationManger.Initilize();

    		try {
	    		MaraMentor.lastLoggedInCountry = window.localStorage.getItem("lastLoggedInCountry");
	    		MaraMentor.lastLoggedInMobile = window.localStorage.getItem("lastLoggedInMobile");

	    		MaraMentor.userName = window.localStorage.getItem("userName");
	    		MaraMentor.userImage = window.localStorage.getItem("userImage");
	    		MaraMentor.userIndustry = window.localStorage.getItem("userIndustry");
			} catch(e) {}

    		MaraMentor.LoginSuccess();
        }
       else{
        	MaraMentor.WelcomeScreen();
       }

       //GaganChanges
       if(platform=="iOS"){
    		setTimeout(function() {
				navigator.splashscreen.hide();
			}, 100);

    	}

    },
     SetupHeaderFooterNavigation: function () {
        MaraMentor.navBar = cordova.require("cordova/plugin/iOSNavigationBar");
        MaraMentor.navBar.init();
        MaraMentor.navBar.create();
    },
    WelcomeScreen: function(){
      	MaraMentor.MakeAjaxCallHTML("views/welcome.html", MaraMentor.WelcomeScreenSuccess, CommonFailFunction);
   	},

    WelcomeScreenSuccess: function (result) {

    	//GaganChanges
    	if(platform=="iOS")
    	$('body').height(deviceHeight2+"px");


    	MaraMentor.HideHeader();
    	MaraMentor.currentScreen = "welcome";
    	MaraMentor.welcomehtml=result;
    	MaraMentor.ChangePageContent(result);
		MaraMentor.RemoveScrollBar();
    	if ($(".BgWrap").length) {
    		if(platform=="iOS"){
    			$(".BgWrap").css("padding-bottom","100%");
    		}
    		else{
    			 var height = $(window).height();
    		$(".BgWrap").css("height",height+"px");
    		}

    	}

		setTimeout(function() {
			$("#wrapper > #scroller").css("top","0px");
			$("#scroller").removeAttr("style");
		}, 500);
	},

	LoginSuccess: function(){
		//AnalyticalManager.Tag("Login Success");
		//MaraMentor.PulseGenerator();

		try{
			window.localStorage.setItem( "sessionId" , MaraMentor.sessionId);
			window.localStorage.setItem( "userName" , MaraMentor.userName);
			window.localStorage.setItem( "userImage" , MaraMentor.userImage);
			window.localStorage.setItem( "userIndustry" , MaraMentor.userIndustry);
		} catch(e) { }

		MaraMentor.isLogin = true;

		fnTrending();

		MaraMentor.RefreshSideMenu();

		if (!debug)
			UserContactManager.FetchUserContacts();

		PushNotificationManger.Initilize();

/*
		clearInterval(pulseInterval);
        if (pulseInterval==null)
        	pulseInterval = setInterval(function(){MaraMentor.PulseGenerator()();},15000);
*/

	},

/*
	pulseDestroy: function() {
		clearInterval(pulseInterval);
	},*/


	PulseGenerator: function() {
		refreshCounter++;

		if (!MaraMentor.isCountrySetup)
			MaraMentor.GetAllCountries();

		//Will run when user is logged in
		if ( MaraMentor.sessionId ){

			if (myScroll != null)
				MaraMentor.RefreshScrollBar();

			if (refreshCounter > 1){
				NotificationManager.NewNotification();
				refreshCounter=0;
			}

		} else {
			$(".searchHeading").hide();
		}

		MaraMentor.RefreshSideMenu();
	},

	ShowHideSideMenu:function(){
		if(MaraMentor.isSideMenuShown){
			$("#st-container").removeClass("st-menu-open");
			$("#st-container, .st-pusher").css("height","");

			MaraMentor.RefreshScrollBar();
			MaraMentor.isSideMenuShown = false;

			setTimeout(function() {
			                $('.st-menu ul').scrollTop(0);
			            }, 50);


		}else{

			$("#st-container").addClass("st-menu-open");
			myScroll.scrollTo(0,0);
			MaraMentor.RefreshScrollBar();
			MaraMentor.RefreshMenuScrollBar();
			setTimeout(function() {
			if (myScroll!=null)
				MaraMentor.RefreshScrollBar();						//Added by RANA
			},400);

			MaraMentor.isSideMenuShown = true;

		}
	},

	RefreshSideMenu: function(){

		/*if (MaraMentor.lastImageUrl != MaraMentor.userImage) {
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					MaraMentor.lastImageUrl = MaraMentor.userImage;
					var img = document.getElementById('menu_userimage');
					var url = window.URL || window.webkitURL;
					img.src = url.createObjectURL(this.response);
					
				} else if (this.readyState == 4 && this.status == 0) {
					//alert("imageError");
					$("#menu_userimage").attr("src", gravatarImage);
				}
			}
			xhr.open('GET', MaraMentor.userImage);
			xhr.responseType = 'blob';
			xhr.send();
		}*/


		 if ($("#menu_userimage").attr("src") !== MaraMentor.userImage)
			 $("#menu_userimage").attr("src", MaraMentor.userImage);

		//if (NotificationManager.newNotifications)
			$("#sidemenu_notifications").text( NotificationManager.newNotifications );

		if(checkIfNullorUndefined(MaraMentor.userIndustry))
   			MaraMentor.userIndustry = "";

		$("#menu_username").text(MaraMentor.userName);
		$("#menu_industry").text(MaraMentor.userIndustry);

		if (MaraMentor.verify_status=="verified")
			$('#activatedUser').show();
		else
			$('#activatedUser').hide();


		if (MaraMentor.verify_status=="can_verify" || MaraMentor.verify_status=="pending")
			$("#verify_account_link").show();
		else
			$("#verify_account_link").hide();

	},

    RemoveScrollBar: function () {
		if (myScroll){
			myScroll.destroy();
			myScroll = null;
			setTimeout(function() {
				if (myScroll!=null) {
					myScroll.destroy();
					myScroll = null;
					pullDownEl = null;
				}
			}, 500);
			//myScroll.stop();
	    	//myScroll.disable();
	        //myScroll = "";
	    }
		pullDownEl = null;
		pullDownOffset = "0";
		MaraMentor.currentScreen = MaraMentor.currentScreen=="trending" ? "" : MaraMentor.currentScreen;
		$("#pullDown").css("display","none");
		$("#wrapper > #scroller").css("top","0px");
    },

    ShowLoader: function () {
		$("#loading").css("display","block");
    },

    HideLoader:function(){
		$("#loading").css("display","none");
    },

    HideSideBar:function(){
    	if ($("#st-container").hasClass("st-menu-open")){
    		$("#st-container").removeClass("st-menu-open");
    			setTimeout(function() {
			//	$("#wrapContent").css("min-height","");
				MaraMentor.RefreshScrollBar();						//Added by RANA
				$('.st-menu ul').scrollTop(0);
			}, 400);

		//	$("#st-container, .st-pusher").css("min-height",""); 		//Added by RANA
		//	$("#st-container, .st-pusher").css("max-height",""); 		//Added by RANA
		}
    },

    HideHeader: function () {
       if(platform=="iOS"){
		    	MaraMentor.navBar.hide();
		       MaraMentor.navBar.hideLeftButton();
		       MaraMentor.navBar.hideRightButtons();
		        $("#wrapper").css("top","0px").css("height","100%");
			    $("#wrapContent").css("height","100%").css("margin-top","0px");
		   }
		   else{
		   	 	$("#header").hide();
			    $("#wrapper").css("top","0px").css("height","100%");
			    $("#wrapContent").css("height","100%").css("margin-top","0px");

		   }
    },

    ShowHeader: function () {
    	/*native code starts here*/
    	if(platform=="iOS"){
	 	   MaraMentor.navBar.show();
	       MaraMentor.navBar.showLeftButton();
	       MaraMentor.navBar.showRightButtons();
	       $("#wrapper").css("height",deviceHeight).css("background","#f2f2f2");
	       MaraMentor.RefreshScrollBar();
	       //GaganChanges

  		}
  		else{
        $("#header").show();
        //$("#wrapper").css("top","41px").css("height","100%").css("background","#f2f2f2");
        $("#wrapper").css("top","41px").css("height","92%").css("background","#f2f2f2");
        //$("#wrapper").css("top","41px").css("height","93%").css("background","#f2f2f2");
	   // $("#wrapContent").css("height","90%").css("margin-top","58px");
	}
    },

    ChangeHeaderText: function (newText) {
		/*native code starts here*/
		   if(platform=="iOS"){
		   	    //GaganChanges
		    	//MaraMentor.HideHeader();
		    	$("#wrapper").css("top","0px").css("height","100%");
			    $("#wrapContent").css("height","100%").css("margin-top","0px");
		    }
		    else{
		    	MaraMentor.ShowHeader();
		    }

        if (newText != "") {

        	if(platform=="iOS"){
        	var HeaderText=newText.substr(0,1).toUpperCase()+newText.substr(1).toLowerCase();
        	 MaraMentor.navBar.setTitle(HeaderText);/*native code*/
        	}
            $("#headerText").text(newText);
        }

		// change side bar images... code start here..
        if(newText  == 'Trending' ){
         	$('#Trending span img').attr('src', 'assets/images/trending.png');
         	$('#Trending span').css('color', '#dd2459');
         }
        else{
         $('#Trending span img').attr('src', 'assets/images/trending_grey.png');
         $('#Trending span').css('color', '#5a5a5a');
     	}

        if(newText  == 'fashion' ){
        	 $('#fashion span img').attr('src', 'assets/images/fashion.png');
        	 $('#fashion span').css('color', '#dd2459');
     	}
        else{
        	 $('#fashion span img').attr('src', 'assets/images/fashion_grey.png');
        	$('#fashion span').css('color', '#5a5a5a');
     	}

        if(newText  == 'beauty' ){
         	$('#beauty span img').attr('src', 'assets/images/beauty.png');
         	$('#beauty span').css('color', '#dd2459');
        }
        else{
        	 $('#beauty span img').attr('src', 'assets/images/beauty_grey.png');
        	 $('#beauty span').css('color', '#5a5a5a');
     	}

        if(newText  == 'nollywood' ){
         	$('#nollywood span img').attr('src', 'assets/images/nollywood.png');
         	$('#nollywood span').css('color', '#dd2459');
         }
        else{
         $('#nollywood span img').attr('src', 'assets/images/nollywood_grey.png');
         $('#nollywood span').css('color', '#5a5a5a');
     	}

        if(newText  == 'music' ){
         	$('#music span img').attr('src', 'assets/images/music.png');
         	$('#music span').css('color', '#dd2459');
         }
        else{
         $('#music span img').attr('src', 'assets/images/music_grey.png');
         $('#music span').css('color', '#5a5a5a');
     	}

        if(newText  == 'gossip' ){
         	$('#gossip span img').attr('src', 'assets/images/gists.png');
         	$('#gossip span').css('color', '#dd2459');
         }
        else{
         $('#gossip span img').attr('src', 'assets/images/gists_grey.png');
          $('#gossip span').css('color', '#5a5a5a');
     	}

        if(newText  == 'news' ){
         	$('#news span img').attr('src', 'assets/images/news.png');
         	$('#news span').css('color', '#dd2459');
         }
        else{
         $('#news span img').attr('src', 'assets/images/news_grey.png');
         $('#news span').css('color', '#5a5a5a');
     	}

     	if(newText  == 'sports' ){
         	$('#sports span img').attr('src', 'assets/images/sports.png');
         	$('#sports span').css('color', '#dd2459');
         }
        else{
         $('#sports span img').attr('src', 'assets/images/sports_grey.png');
         	$('#sports span').css('color', '#5a5a5a');
         }



     	if(newText  == 'New Connections' ){
         	$('#connection span img').attr('src', 'assets/images/connection.png');
         	$('#connection span').css('color', '#dd2459');
         }
        else{
        	$('#connection sapn img').attr('src', 'assets/images/connection_grey.png');
        	$('#connection span').css('color', '#5a5a5a');
        }
        //end..

		if (newText  == 'Trending' ||
			newText  == 'fashion' ||
			newText  == 'beauty' ||
			newText  == 'nollywood' ||
			newText  == 'music' ||
			newText  == 'gossip' ||
			newText  == 'sports' ||
			newText  == 'news'
			)
			MaraMentor.isDashboard =  true;
		else
			MaraMentor.isDashboard =  false;


       if (newText=="Login" || newText=="Sign Up" || MaraMentor.backPages.length > 1 ) {
            $("#header .headingHeader").html("<img src='assets/images/back.png'>");
            $("#header .headingHeader").attr('onclick', 'MaraMentor.HandleBack()');
            $("#header .headingHeader").css('visibility', 'visible');
           	$("#headerText").css('margin', '-2% 0 -2px 3%');

           	if(platform=="iOS"){
	           	/*native code starts*/
	            MaraMentor.navBar.show();
	                  MaraMentor.navBar.setupLeftButton(
	                  "Back",
	                  "Back.png", // or your own file like "/www/stylesheets/images/ajax-loader.png",
	                  function () {
	                  MaraMentor.HandleBack();
	                  //alert("Button Clicked");
	            });
	            MaraMentor.navBar.showLeftButton();



	           if (newText=="Profile" || newText=="Followers/followings" || newText=="Search" || newText=="Profile") {
			           	MaraMentor.navBar.show();
			            var options;
			            var searchBtn=["Search",
			                "Search.png",{},// or your own file like "/www/stylesheets/images/ajax-loader.png",
			                function () {
			                SearchManager.SearchHtml();
			               // alert("Search Button Clicked");

			                }];
			                var editBtn=["Edit",
			                "Edit.png",{},// or your own file like "/www/stylesheets/images/ajax-loader.png",
			                function () {
			                StatusUpdate.PostStatus('post_update');
			                //alert("Edit Button Clicked");
			                }];
			            MaraMentor.navBar.setupRightButtons(searchBtn,editBtn);

	        	}
	        	else{
	        		MaraMentor.navBar.hideRightButtons();
	        	}
	 		/*native code ends*/

		}
        } else {
 			if ($("#header .headingHeader").html() != "<button data-effect='st-effect-4' id='menu-bars'></button>"){
            	$("#header .headingHeader").removeAttr('onclick');
  		 		$("#header .headingHeader").html("<button data-effect='st-effect-4' id='menu-bars'></button>");
            	$("#header .headingHeader").css('visibility',"visible");
            	$("#headerText").css('margin', '-2% 0 -2px 17%');
            	 if(platform=="iOS"){
            	if(newText=="New connections"){
	            		/*native code starts*/
	            	MaraMentor.navBar.show();
	                  MaraMentor.navBar.setupLeftButton(
	                  "Back",
	                  "Back.png", // or your own file like "/www/stylesheets/images/ajax-loader.png",
	                  function () {
	                  MaraMentor.HandleBack();
	                  //alert("Button Clicked");
	            	});
	            	MaraMentor.navBar.showLeftButton();
            	}
            	else{
            		 MaraMentor.navBar.setupLeftButton(
		            "TopMenu",
		            "TopMenu.png", // or your own file like "/www/stylesheets/images/ajax-loader.png",
		            function () {
		            MaraMentor.HideSideBar();
		            MaraMentor.ShowHideSideMenu();
		            //alert("Button Clicked");
		            });
		             MaraMentor.navBar.showLeftButton();
            	}

            	/*native code starts*/
		            MaraMentor.navBar.show();
		            var options;
		            var searchBtn=["Search",
		                "Search.png",{},// or your own file like "/www/stylesheets/images/ajax-loader.png",
		                function () {
		                SearchManager.SearchHtml();
		               // alert("Search Button Clicked");

		                }];
		                var editBtn=["Edit",
		                "Edit.png",{},// or your own file like "/www/stylesheets/images/ajax-loader.png",
		                function () {
		                StatusUpdate.PostStatus('post_update');
		                //alert("Edit Button Clicked");
		                }];
		            MaraMentor.navBar.setupRightButtons(searchBtn,editBtn);


		               MaraMentor.navBar.showRightButtons();
      /*native code ends*/
  		 	}
  		 	}
			 if(platform!="iOS"){
				bindSideMenu();
			}
           // $("#header .editIcon").attr('src', 'assets/images/search.png');
           // $("#header .editIcon").attr('onclick', 'GlobalSearchManager.GetGlobalSearchData(1)');
        }

        if(!MaraMentor.sessionId || parseInt(MaraMentor.sessionId)<=0 )
        {
        	$('#wrapper').addClass('black-bg');
           	$('#loginBg').addClass('black-bg');
        	$(".searchHeading").hide();
        }else{
        	$('#wrapper').removeClass('black-bg');
           	$('#loginBg').removeClass('black-bg');
        	$(".searchHeading").show();
		}

       if (newText=="Login" || newText=="Sign Up" || MaraMentor.currentScreen=="login")
			MaraMentor.sessionId=0;

		//GaganChanges
	      if(platform=="iOS")
			$("#wrapper").css("height",deviceHeight);

    },

    MakeAjaxCall: function (requestData, successFunction, failureFunction) {
        MaraMentor.isAjaxCall = true;
        requestType = "POST";
        this.ShowLoader();
        if (!window.navigator.onLine) {
            //MaraMentor.showAlert("No Internet Connection.", "Message")
            // return false;
        }

        if (!requestData) {
            requestData = "";
        }
        if (!successFunction) {
            successFunction = function () {};
        }
        if (!failureFunction) {
            failureFunction = function () {};
        }
        if (navigator.appName == "Microsoft Internet Explorer") {
            asyncString = true;
        } else {
            asyncString = true;
        }

        if (MaraMentor.sessionId && (requestData != "" || MaraMentor.sessionId != 0))
			requestData += "&session="+MaraMentor.sessionId+"&platform="+platform+"&apiKey="+apiKey;


        var xmlhttp;
            if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else { // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }

            xmlhttp.onreadystatechange = function () {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    $("#loading2").hide();
                    MaraMentor.isAjaxCall = false;
                    MaraMentor.HideLoader();
                    successFunction(xmlhttp.responseText);
                    MaraMentor.isAjaxAlertBoxShowing=false;
                } else if (xmlhttp.readyState == 4 && xmlhttp.status == 0) {
                    $("#loading2").hide();
                    MaraMentor.IsLoadMore = "false";
                    MaraMentor.isAjaxCall = false;
                    MaraMentor.HideLoader();

                    if (!MaraMentor.isAjaxAlertBoxShowing){
                    	MaraMentor.isAjaxAlertBoxShowing = true;
                    	MaraMentor.ShowAlert("Sorry could not process your request now.", "Message");
                    }
                }
            }
            xmlhttp.open("POST", serverURL, true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
            xmlhttp.timeout = 30000;
            xmlhttp.send(requestData);
    },

    MakeAjaxCallHTML: function (requestUrl, successFunction, failureFunction) {
        this.ShowLoader();
        requestType = "POST";
        requestData = "";
        MaraMentor.isDashboard = false;
        if (!requestUrl) {
            return;
        }
        if (!successFunction) {
            successFunction = function () {};
        }
        if (!failureFunction) {
            failureFunction = function () {};
        }


         if(platform=="iOS"){
	        $.ajax({
	      type: requestType,
	      url: requestUrl,
	      data: requestData,
	      //dataType: "text/html",
	      timeout: 30000,
	      success: function (data, status, xhr) {
	        MaraMentor.isAjaxCall = false;
	        MaraMentor.HideLoader();
	        successFunction(data);
	      },
	      error: function (xhr, errorType, error) {
	        //console.log(error);
	        //alert("htmlErr")
	        MaraMentor.isAjaxCall = false;
	        MaraMentor.HideLoader();
	        MaraMentor.ShowAlert("Sorry could not process your request now.", "Message");//failureFunction(error);
	      },
	      complete: function (xhr, status) {
	      }
	    });
	    }
	    else{
        var xmlhttp;
        if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                MaraMentor.isAjaxCall = false;
                MaraMentor.HideLoader();
                successFunction(xmlhttp.responseText);
            } else if (xmlhttp.readyState == 4 && xmlhttp.status == 0) {
                MaraMentor.isAjaxCall = false;
                MaraMentor.HideLoader();
               // MaraMentor.ShowAlert("Sorry could not process your request now.", "Message");
            }
        }
        xmlhttp.open("POST", requestUrl, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
      	xmlhttp.timeout = 30000;
        xmlhttp.send(requestData);
    }

    },

    MakeAjaxCall2: function ( requestData, successFunction, failureFunction) {
        if (!window.navigator.onLine) {
            //MaraMentor.showAlert("No Internet Connection.", "Message")
            // return false;
        }
        if (!requestData) {
            requestData = "";
        }

        requestType = "POST";
        if (!successFunction) {
            successFunction = function () {};
        }
        if (!failureFunction) {
            failureFunction = function () {};
        }
        if (navigator.appName == "Microsoft Internet Explorer") {
            asyncString = true;
        } else {
            asyncString = true;
        }

       	if (MaraMentor.sessionId && (requestData != "" || MaraMentor.sessionId != 0))
			requestData += "&session="+MaraMentor.sessionId+"&platform="+platform+"&apiKey="+apiKey;

        if (true) {

            var xmlhttp;
            if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else { // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }

            xmlhttp.onreadystatechange = function () {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                    successFunction(xmlhttp.responseText);
                } else if (xmlhttp.readyState == 4 && xmlhttp.status == 0) {
					//MaraMentor.showAlert("Connection Error.", "Message");
                }
            }
            xmlhttp.open("POST",  serverURL, true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
           	xmlhttp.timeout = 30000;
            xmlhttp.send(requestData);
        }
    },

	RefreshMenuScrollBar:function(){
		if ( menuScrollAttached )
			menuScroll.refresh();
    },

	RefreshScrollBar:function(){
       if (myScroll == null) {
       	  	if ($("#pullDown").length){
        	document.getElementById("pullDown").style.display = "block";
        	pullDownEl = document.getElementById('pullDown');
        	pullDownOffset = pullDownEl.offsetHeight;
		}
		else
		{
			pullDownEl =null;
        	pullDownOffset = "0";
		}
		 var _userTransform = false;

        if(MaraMentor.androidVersion >= 4)
            _userTransform = true;
       		 myScroll = new iScroll('wrapper', {
                scrollbars: false,
                useTransform: _userTransform,
                useTransition:_userTransform,
                zoom: false,
                topOffset: pullDownOffset,
                onRefresh: function () {
                    if (pullDownEl && pullDownEl.className.match('loading')) {
                        pullDownEl.className = '';
                        pullDownEl.querySelector('.pullDownLabel').innerHTML = 'Pull down to refresh...';
                    }
                },
                onScrollMove: function () {
					if ( MaraMentor.isDashboard && !$("#st-container").hasClass("st-menu-open")) {

                    document.getElementById("pullDown").style.visibility = "visible";
                    if (this.y > 5 && !pullDownEl.className.match('flip')) {
                        pullDownEl.className = 'flip';
                        pullDownEl.querySelector('.pullDownLabel').innerHTML = 'Release to refresh...';
                        this.minScrollY = 0;
                    } else if (this.y < 5 && pullDownEl.className.match('flip')) {
                        pullDownEl.className = '';
                        pullDownEl.querySelector('.pullDownLabel').innerHTML = 'Pull down to refresh...';
                        this.minScrollY = -pullDownOffset;
                    }
					} else {
						//if ("#loadMoreButton")

						if (MaraMentor.IsLoadMore != "false" && $("#loadMoreFollowersButton").length)
							$("#loadMoreFollowersButton").hide();
						if (MaraMentor.IsLoadMore != "false" && $("#loadMoreButton").length)
							$("#loadMoreFollowersButton").hide();
						if ($("#pullDown").length)
							document.getElementById("pullDown").style.visibility = "hidden";
					}

                },
                onScrollEnd: function () {
                	/* if (this.y == this.maxScrollY && !MaraMentor.IsLoadMore && !$("#st-container").hasClass("st-menu-open") ) {
                       if(document.getElementById('loadMoreButton')){
                           // document.getElementById('loadMoreButton').style.visibility="visible";
                            $('#loadMoreButton').css('visibility','visible');
                            $('.loadMore').css('visibility','visible');
                            MaraMentor.scrolltop = 0;
                            MaraMentor.IsLoadMore = true;
                            $('#loadMoreButton').text("");
                            setTimeout(function() {   //calls click event after a certain time
                                $('#loadMoreButton').click();
							}, 1000);
                        }
					} */
					if (this.y == this.maxScrollY && MaraMentor.IsLoadMore == "false" && !$("#st-container").hasClass("st-menu-open") ) {
                       if(document.getElementById('loadMoreButton')){
                       		//console.log("load More Mentor. OK");
                       		if(MaraMentor.isProfileFollowers){
                                document.getElementById('loadMoreFollowersButton').style.visibility="visible";
                               	wrapAnimation = _noAnimation;
                                MaraMentor.scrolltop = 0;
                                MaraMentor.IsLoadMore = "true";
                                MaraMentor.IsLoader = "false";
                                $('#loadMoreFollowersButton').text("");
                                setTimeout(function() {   //calls click event after a certain time
	                                $('#loadMoreFollowersButton').click();
								}, 1000);
                            }
                            else{
                                document.getElementById('loadMoreButton').style.visibility="visible";
                                $('.loadMore').css('visibility','visible');
                               	MaraMentor.scrolltop = 0;
                                MaraMentor.IsLoadMore = "true";
                                MaraMentor.IsLoader = "false";
                                $('#loadMoreButton').text("");
                                setTimeout(function() {   //calls click event after a certain time
	                                $('#loadMoreButton').click();
								}, 1000);
                        	}
                        }
                }
                else if(MaraMentor.IsLoadMore == "true"){
                	try {
                    	document.getElementById("pullDown").style.visibility = "hidden";
                  	} catch (err) {}
                }

                if (MaraMentor.isDashboard == true) {

                    document.getElementById("pullDown").style.visibility = "visible";
                    if (pullDownEl.className.match('flip')) {
                        pullDownEl.className = 'loading';
                        pullDownEl.querySelector('.pullDownLabel').innerHTML = '';
                        //pullDownAction(); // Execute custom function (ajax call?)
						TrendingManager.RefreshTrending();
                    }
                } else {
                	if ($("#pullDown").length)
                    	document.getElementById("pullDown").style.visibility = "hidden";
                }
				}
            });
        myScroll.options.onBeforeScrollStart = function(e) {
	                var nodeType = e.explicitOriginalTarget ? e.explicitOriginalTarget.nodeName.toLowerCase():(e.target ? e.target.nodeName.toLowerCase():'');
	                if(nodeType !='select' && nodeType !='option' && nodeType !='input' && nodeType!='textarea')
	                    e.preventDefault();
        }
        } else {
        	myScroll.enable();

            setTimeout(function () {
            	if ( myScroll!=null )
                	myScroll.refresh()
            }, 10);
        }

        MaraMentor.SetUpExternalLinks();

    },


	ChangePageContent: function (content, pageSource, scrollPosition) {
		MaraMentor.HideSideBar();
		MaraMentor.isTermPage = false;
		//$("#wrapContent").css("padding","5px 0 60px 0");
    	var wrapContentDiv = document.getElementById("wrapContent");
    	//
    	//$("#wrapContent").addClass('animated bounceIn');
    	
    	$("#wrapContent").addClass('animated fadeIn');
    	$('#wrapContent').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){$("#wrapContent").removeClass('animated fadeIn');});

        wrapContentDiv.innerHTML = content;

        if (myScroll && MaraMentor.scrolltop == 1)
            myScroll.scrollTo(0,0,0);

        if(myScroll && scrollPosition){
            setTimeout(function () {
                myScroll.scrollTo(0,scrollPosition,0);
            }, 100);
        }

        wrapContentDiv.style.display="block";
        $("#loading").hide();

		//MaraMentor.RefreshScrollBar();

        if(!debug && MaraMentor.ShowRatingPopup=="true" && MaraMentor.isLogin  && MaraMentor.UserClicks >2){
            MaraMentor.ShowAppRating();
            MaraMentor.appRatingPromptCount = 0;
            MaraMentor.ShowRatingPopup="false";
            MaraMentor.UserClicks = 0;
        }

        if(MaraMentor.sessionId)
        	$('#wrapper').removeClass('black-bg');

        if(MaraMentor.isLogin)
            MaraMentor.UserClicks++;

        MaraMentor.IsLoadMore = "false";
        MaraMentor.isScrollPostion = false;
        MaraMentor.scrolltop = 1;
    },

    SetUpExternalLinks: function(){
        $("#wrapContent").find("a").each(function(index){
          var link = $.trim($(this).attr("href"));
          if(link != "javascript:void(0)" && link!="#" && link != "javascript:void(0);"){
            $(this).attr("href","javascript:void(0)");
            $(this).bind("click", function(e){openUrl(link)});
          }
        })
    },

    showToastMsg: function (msg) {
    	if(msg==""||msg==null){
        	msg="Sorry, we​ could not process your request now.​ Please try again later.";
     	}

     	if (!debug){
     		navigator.notification.alert(
            msg, // message
            alertDismissed, // callback
            'Message', // title
            'Ok' // buttonName
        	);
		}else{
       		alert(msg);
       	}
    },

	PushPageRecord: function (pushPage) {
        if (pushPage == "") {
            return;
        }

		MaraMentor.currentScreen = pushPage;

        var t = MaraMentor.backPages.length;
        var lastPage = MaraMentor.backPages[t - 1];
        if (t > 0) {
            if (lastPage != pushPage) {
                MaraMentor.backPages.push(pushPage);
            }
        } else {
            MaraMentor.backPages.push(pushPage);
        }
    },

	HandleBack: function () {

		if(MaraMentor.isTermPage)
		{
            	$('#forumdata').show();
        		$('#termData').hide();
        		MaraMentor.isTermPage = false;

               return 0;
		}

		if (MaraMentor.currentScreen=="login")
			MaraMentor.sessionId = 0;

        var t = (MaraMentor.backPages.length - 1);

		if (t==0  && MaraMentor.isLogin == "true" && MaraMentor.backPages[t] !="dashboard")
		{
			DashManager.pageNo -=1;
        	MaraMentor.CurrenMenu = "home";
            DashManager.SetDashboardHTML();
            return 0;
		}

		//No action if back page is signUpSteps
		if (MaraMentor.backPages[t - 1] == "signUpSteps" )
			return 0;
		else if (MaraMentor.backPages[t] =="dashboard"  || t==0){
			if (!debug)
				navigator.notification.confirm("Are you sure to exit from Mara Trend App ?", onExitConfirm, "Confirmation", "Yes,No");
			return 0;
		}

        if (t > 0) {
            MaraMentor.isBack = 'true';

            MaraMentor.backPages.pop();
            var newPage = MaraMentor.backPages[t - 1];
            var targetId =0;
            if (newPage.indexOf("#") >= 0){
             var arr = newPage.split('#');
             newPage = arr[0];
             targetId =  arr[1];
            }
            switch (newPage) {
            case "trending":
            	fnTrending( TrendingManager.filter );
                break;
            case "welcome":
            	MaraMentor.WelcomeScreen();
                break;
            /*case "status_update":
            	fnTrending( TrendingManager.filter );
                break;*/
            case "single_activity":
            	if(targetId ==0)
              		SingleActivityManager.SingleActivity(SingleActivityManager.activity_id, SingleActivityManager.activity_index);
            	else
             		 SingleActivityManager.SingleActivity(targetId, SingleActivityManager.activity_index);
                break;
            case "completeprofile":
            	CompleteYourProfile.CompleteProfile();
                break;
			case "edit_profile":
				EditProfileManager.EditProfile(EditProfileManager.user_id, EditProfileManager.page_source);
			case "profile":
            	 if(targetId == 0)
 					ProfileManager.Profile(FollowersManager.user_id);
				  else
				     ProfileManager.Profile(targetId);
                break;
            case "search":
                SearchManager.SearchSuccessHtml();
                break;
			case "user_list":
                UserListManager.UserList();
                break;
			case "notification":
				NotificationManager.Notification();
				break;
            case "followers":
              	var current_tab = 'follower';
               	if(FollowersManager.current_tab){
                       current_tab = FollowersManager.current_tab;
               	}else{

               	}
               	if(targetId == 0)
                	FollowersManager.FollowerDiv(MaraMentor.sessionId,current_tab);
               	else
                FollowersManager.FollowerDiv(targetId,current_tab);
            break;
            default:
               if(MaraMentor.isLogin=="true" || MaraMentor.isLogin){
                     DashManager.pageNo -=1;
                     //DashManager.SetDashboardHTML();
                }
                else{
                    LoginManager.Login();
                }
            }
             MaraMentor.isBack = 'false';
        }
        else{
        	 //LoginManager.SetWelcomeHTML();
                LoginManager.Login();
           // navigator.notification.confirm("Are you sure you want to exit ?", onExitConfirm, "Confirmation", "Yes,No");
        }
    },
    showAlert: function (msg, header) {
      if(msg==""||msg==null){
          msg = "Sorry, we​ could not process your request now.​ Please try again later.";
      }
       if (!debug){
        navigator.notification.alert(
            msg, // message
            alertDismissed, // callback
            'Message', // title
            'Ok' // buttonName
        );
       } else {
       		alert(msg);
       }
    },
    ShowAlert: function (msg) {
      if(msg==""||msg==null){
        msg="Sorry, we​ could not process your request now.​ Please try again later.";
      }
      if (!debug){
        navigator.notification.alert(
            msg, // message
            alertDismissed, // callback
            'Message', // title
            'Ok' // buttonName
        );
        } else {
       		alert(msg);
       }
    },

 	GetAllCountries: function () {
 		if(MaraMentor.isCountrySetup)
            return false;

        if (MaraMentor.savedSessionId == "") {
            MaraMentor.ShowLoader();
        }

        //var data = "func=getAllCountryList&api_key=92b7d3ab2b864e8eee752fe8e979960c&screen=Medium";
        //MaraMentor.MakeAjaxCall( data, MaraMentor.GetAllCountriesSuccess, CommonFailFunction);
        MaraMentor.GetAllCountriesSuccess();
    },

    GetAllCountriesSuccess: function ( arg ) {
    	var arg =getCountries();
       	MaraMentor.HideLoader();
        if ( arg && arg.countryContent &&  arg.countryContent.length) {
			MaraMentor.isCountrySetup = true;
            MaraMentor.country_array = arg.countryContent;
        }
        if (MaraMentor.currentScreen=="login"){
        	if ($("#countrycode").length)
	        	MaraMentor.SetupCountriesAutocomplete($("#countrycode").val());
	        else
	        	MaraMentor.SetupCountriesAutocomplete();
        }
     },

    SetupCountriesAutocomplete: function (country_code) {
    	if (!MaraMentor.country_array || MaraMentor.country_array.length<=0)
    		return false;

        var countries = [];
        for (var c = 0; c < MaraMentor.country_array.length; c++) {
            countries[c] = {
                id: MaraMentor.country_array[c]['c_phone_prefix'],
                title: MaraMentor.country_array[c]['country_nm'] + " (+" + MaraMentor.country_array[c]['c_phone_prefix'] + ")"
            };

        	if (country_code && country_code == MaraMentor.country_array[c]['c_phone_prefix']){
        		$("#countrycode").val(country_code)
        		$('#countrytext').val(MaraMentor.country_array[c]['country_nm'] + " (+" + MaraMentor.country_array[c]['c_phone_prefix'] + ")")
        	}

        	if (!country_code && MaraMentor.country_array[c]['iso'].toLowerCase()== MaraMentor.countryIsoCode.toLowerCase()){
        		$("#countrycode").val( MaraMentor.country_array[c]['c_phone_prefix'])
        		$('#countrytext').val(MaraMentor.country_array[c]['country_nm'] + " (+" + MaraMentor.country_array[c]['c_phone_prefix'] + ")")
        	}
        }

        $('#countrytext').tinyAutocomplete({
            data: countries,
            onEscape: function (val) {
                //alert(val);
            },
            onSelect: function (el, val) {
                if (val == null) {
                    $(this).focus();
                } else {
                    $("#countrycode").val(val.id);
                    $(this).val(val.title);
                }
            }
        });
    },

    PopulateDateField:function(index){
		if (index == "na")
			dom = 0;
		else if (index== 2)
			dom = 28;
		else if (index== 4 || index== 6 || index== 9 || index== 11)
			dom = 30;
		else
			dom = 31;

		var xx = 0;
		var old_date='';
		if ($("#day").val())
			old_date=$("#day").val();

		$("#day option").remove();
		$("#day").append('<option value="na">Day</option>');
		while (xx++ < dom)
			$("#day").append('<option value="'+xx+'">'+xx+'</option>');

		if ($("#day").val() !='' && $("#day option[value='"+old_date+"']").length > 0)
			$("#day").val(old_date);

		if ($("#year option").length <= 1 ){
			$("#year option").remove();
			$("#year").append('<option value="na">Year</option>');
			var xx = new Date().getFullYear() + 1;
			//var xx = 2010;
			//while (xx-- > 1909)
			while (xx-- > 1935)
				$("#year").append('<option value="'+xx+'">'+xx+'</option>');
				//$("#year").append('<option value="1800">1800</option>');
				//$("#year").append('<option value="1934">1934</option>');
		}
    },

    SetupIndustriesDropdown: function (current_industry) {
		current_industry = typeof current_industry === 'undefined' ? "": current_industry;

    	$("#industry option").remove();
		if (MaraMentor.verify_status == "user_account"){
			$("#industry").append('<option value="">Choose your interest</option>');
		}
		else{
			$("#industry").append('<option value="">Choose your Industry</option>');
		}
		xx=0;
		for (xx in MaraMentor.industry_array){
		//while (xx++ <  MaraMentor.industry_array.length){
			if (current_industry==MaraMentor.industry_array[xx] && current_industry != "")
				$("#industry").append('<option value="'+xx+'" selected="selected">'+MaraMentor.industry_array[xx]+'</option>');
			else
				$("#industry").append('<option value="'+xx+'">'+MaraMentor.industry_array[xx]+'</option>');
		}
       // MaraMentor.setupUserCountryAndMobile();
    },

	setupUserCountryAndMobile:function(){
		var lastLoggedInCountryCode = window.localStorage.getItem("lastLoggedInCountryCode");
     	var lastLoggedInCountryName = window.localStorage.getItem("lastLoggedInCountryName");
     	var lastLoggedInMobile = window.localStorage.getItem("lastLoggedInMobile");

	    if(lastLoggedInMobile!=null || lastLoggedInMobile !=undefined)
	            $("#phone").val(lastLoggedInMobile);

        var countryCode="";
        var countryText="";

    	for (var c = 0; c < MaraMentor.country_array.length; c++) {
                  if(MaraMentor.country_array[c]['phone_prefix']== lastLoggedInCountryCode){
                    countryCode = MaraMentor.country_array[c]['phone_prefix'];
                    countryText = MaraMentor.country_array[c]['country'] + " (+" + MaraMentor.country_array[c]['phone_prefix'] + ")";
                  }
    	}

        if(lastLoggedInCountryCode!=null && lastLoggedInCountryCode!=undefined){
            if(lastLoggedInCountryCode!=""){
             countryCode = lastLoggedInCountryCode;
            }
        }

        if(lastLoggedInCountryName!=null && lastLoggedInCountryName!=undefined){
            if(lastLoggedInCountryName!=""){
             countryText = lastLoggedInCountryName;
           }
        }

        if(countryCode!="" && countryText !="" && countryText!=undefined && countryCode != undefined){
             $("#countrycode").val(countryCode);
             $("#countrytext").val(countryText);
        }
    },

    ShowDemoScreens:function(){
        if($(document).height()>480)
        {

            $("#demoSlideImage_1").attr("src","assets/images/demoScreen/DefaultIphone1@2x.jpg");
            $("#demoSlideImage_2").attr("src","assets/images/demoScreen/DefaultIphone2@2x.jpg");
            $("#demoSlideImage_3").attr("src","assets/images/demoScreen/DefaultIphone3@2x.jpg");
            $("#demoSlideImage_4").attr("src","assets/images/demoScreen/DefaultIphone4@2x.jpg");
            $("#demoSlideImage_5").attr("src","assets/images/demoScreen/DefaultIphone5@2x.jpg");
        }


        MaraMentor.isDemoScreen = true;
        MaraMentor.HideHeader();
      //  MaraMentor.navBar.hide();
       // StatusBar.hide();
               MaraMentor.RemoveScrollBar();

         window.setTimeout(function(){
         	$("#demoSlides").height($(document).height()).show();
        	//$("#wrapper").hide();
        	$("#scroller").hide();
        }, 200);

    },
  	HandlePrevNextDemoScreens:function(arg){

        if(arg == "left"){
            var currentImage = MaraMentor.demoScreenNo;
            //alert(currentImage)
            if(currentImage==1)
                $('#prevTour').show();

            var nextImage = MaraMentor.demoScreenNo +1;

            if(nextImage>5){
                MaraMentor.HideDemoScreens();//nextImage = 1;
                return 0;
            }

            //Move to next screen
            $("#demoSlideImage_"+currentImage).hide("slow", function() {
                //alert( "Animation complete." );
            });
            //MaraMentor.navBar.animateToRight();
            $("#demoSlideImage_"+nextImage).show();

            MaraMentor.demoScreenNo = nextImage;
        }
        else{
            //Move to previous screen

            var currentImage = MaraMentor.demoScreenNo;
            //alert(currentImage)

            var prevImage = MaraMentor.demoScreenNo -1;

            if(prevImage<1){
                $('#prevTour').hide();
                return 0;
            }

            if(prevImage<1)
                prevImage = 5;

            //Move to next screen
            $("#demoSlideImage_"+currentImage).hide("slow", function() {
                //alert( "Animation complete." );
            });
            //MaraMentor.navBar.animateToLeft();
            $("#demoSlideImage_"+prevImage).show("slow", function() {
                //alert( "Animation complete." );
            });

            MaraMentor.demoScreenNo =prevImage;
        }

    },
    HideDemoScreens:function(){
        MaraMentor.demoScreenNo = 1;
        $('#prevTour').hide();
        MaraMentor.isDemoScreen = false;
        MaraMentor.ShowHeader();
       // StatusBar.show();
        //MaraMentor.navBar.show();
        $("#demoSlides").hide();
        $("#demoSlideImage_1, #demoSlideImage_2, #demoSlideImage_3, #demoSlideImage_4, #demoSlideImage_5").hide();
        $("#demoSlideImage_1").show();
        $("#scroller").show();
        window.setTimeout(function(){
	//        $("#pullDown").hide();
	        MaraMentor.RefreshScrollBar();
        }, 200);

        //$("#wrapper").show();


    },

}


/********************  START : LiveValidation controller : RANA **********************/
var LiveValidations = {
	MobileNumber: function (elem, borderNormalColor) {
		if (!elem) return true;
		borderNormalColor = typeof borderNormalColor === 'undefined' ? "#dcdcdc" : borderNormalColor;
		var intRegex = /^\d+$/;
        if(elem.value != "" && (elem.value.search(intRegex) == -1 || elem.value.length <=4 || elem.value.charAt(0) == '0')) {
        	//elem.style.border ="1px solid #ff0000";
            $(elem).css("border-bottom","1px solid #ff0000");
        	elem.focus();
            return false;
        } else {
            //elem.style.border ="1px solid "+borderNormalColor;
            $(elem).css("border-bottom","1px solid #606060");
            //elem.style.border-bottom = "1px solid #606060";
            return true;
        }
   },
   Email: function (elem, borderNormalColor) {
   	if (!elem) return true;
   	borderNormalColor = typeof borderNormalColor === 'undefined' ? "#dcdcdc" : borderNormalColor;
		var emailRegEx = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
       	if(elem.value == "" || emailRegEx.test(elem.value)){
       		//elem.style.border ="1px solid "+borderNormalColor;
       		 $(elem).css("border-bottom","1px solid #606060");
       		return true;
        }else{
            $(elem).css("border-bottom","1px solid #ff0000");
       		elem.focus();
            return false;
        }
    },
   AutoComplete: function (elem, hiddenfield, borderNormalColor) {
   		if (!elem || !hiddenfield) return true;
   		borderNormalColor = typeof borderNormalColor === 'undefined' ? "#dcdcdc" : borderNormalColor;
   		hiddenfield = document.getElementById(hiddenfield);
       	if(hiddenfield.value != ""){
       		//elem.style.border ="1px solid "+borderNormalColor;
       		 $(elem).css("border-bottom","1px solid #606060");
       		return true;
        }else{
            elem.style.border ="1px solid #ff0000";
       		elem.focus();
            return false;
        }
    },
   AlphabetsOnly: function (elem, borderNormalColor) {
   		if (!elem) return true;
   		borderNormalColor = typeof borderNormalColor === 'undefined' ? "#dcdcdc" : borderNormalColor;
		var alphaRegEx =  /^[a-zA-Z ]+$/;
       	if(elem.value=="" || alphaRegEx.test(elem.value)){
       		//elem.style.border ="1px solid "+borderNormalColor;
       		 $(elem).css("border-bottom","1px solid #606060"); //Grey Border
       		return true;
        }else{
            $(elem).css("border-bottom","1px solid #ff0000"); //Red Border
       		//elem.style.border ="1px solid #ff0000";
       		elem.focus();
       		var p = $( "#"+elem.id );
			var offset = p.offset();
			//myScroll.scrollTo(document.activeElement, 100); //Disabled as not working properly
            return false;
        }
    }
}
/********************  END : LiveValidation controller : RANA **********************/

var ImageUploader = {
    imagePath:"",
    uploadSuccessResponse:"",
    api_function:"",

    Upload:function(){
        ImageUploader.imagePath = "";
        ImageUploader.api_function = "";

        navigator.notification.confirm(
            'Upload image via ?', // message
            ImageUploader.SelectImageSource, // callback to invoke
            'Upload Image', // title
            ['Gallery', 'Camera'] // buttonLabels
        );
    },

    SelectImageSource: function(buttonIndex) {
        if (buttonIndex == 1)
            ImageUploader.UploadByGallery();
        else if (buttonIndex == 2)
            ImageUploader.UploadByCamera();
    },

	UploadImageError:function(result){
     	//if(result=="You have no access to photos/camera.")
    	MaraMentor.ShowAlert(result);
    },

    UploadByGallery: function(){
       source = Camera.PictureSourceType.PHOTOLIBRARY;

		//Image Editing is OK on all platforms IOS/BB/ANDROID in Gallery
      	if (ImageUploader.page_source == "profile_edit")
    	//On Profile Edit crop size will be 150x150 box
	        navigator.camera.getPicture(ImageUploader.GetImageSuccess, ImageUploader.UploadImageError, {
	            quality: image_upload_quality,
	            destinationType: Camera.DestinationType.FILE_URI,
	            sourceType: source,
	            encodingType: Camera.EncodingType.JPEG,
           		/*allowEdit: true,
            	targetWidth: 150,
            	targetHeight: 150*/
	        });
		else
		//On other images crop will be any size
	        navigator.camera.getPicture(ImageUploader.GetImageSuccess, ImageUploader.UploadImageError, {
	            quality: image_upload_quality,
	            destinationType: Camera.DestinationType.FILE_URI,
	            sourceType: source,
	            encodingType: Camera.EncodingType.JPEG,
           		//allowEdit: true,
	        });


    },

    UploadByCamera: function(){
    	if( "BB" == platform )
    		//When app_platform is BlackBerry then Image Editing is not supported
	        navigator.camera.getPicture(ImageUploader.GetImageSuccess, ImageUploader.UploadImageError, {
	          	quality: image_upload_quality,
	          	sourceType: Camera.PictureSourceType.CAMERA,
	          	destinationType: Camera.DestinationType.FILE_URI,
	          	encodingType: Camera.EncodingType.JPEG,
	          	correctOrientation: true
	      });

		//Other than BlackBerry Image Editing is OK
      	if ("BB" != platform && ImageUploader.page_source == "profile_edit")
    		//On Profile Edit crop size will be 150x150 box
	      	navigator.camera.getPicture(ImageUploader.GetImageSuccess, ImageUploader.UploadImageError, {
		          	quality: image_upload_quality,
		          	/*allowEdit: true,
					  targetWidth: 150,
					  targetHeight: 150,*/
		          	sourceType: Camera.PictureSourceType.CAMERA,
		          	destinationType: Camera.DestinationType.FILE_URI,
		          	encodingType: Camera.EncodingType.JPEG,
		          	correctOrientation: true
		      });
		else
    		//On other images crop will be any size
	      	navigator.camera.getPicture(ImageUploader.GetImageSuccess, ImageUploader.UploadImageError, {
		          	quality: image_upload_quality,
		          	//allowEdit: true,
		          	sourceType: Camera.PictureSourceType.CAMERA,
		          	destinationType: Camera.DestinationType.FILE_URI,
		          	encodingType: Camera.EncodingType.JPEG,
		          	correctOrientation: true
		      });

    },

    GetImageSuccess: function( imagePath ){
        ImageUploader.imagePath = imagePath;
        if (ImageUploader.page_source == "post_update")
 			$("#content_area").html("<div class='postedImage'><img src='assets/images/close.png' class='shareCancil' onclick='StatusUpdate.DeleteImage();'><img class='shareActivity' src='"+imagePath+"' /></div>");
 		if (ImageUploader.page_source == "profile_edit")
            $("#edit_profile_img").attr('src',imagePath);
    },

    UploadImage2Server: function(){
        if(ImageUploader.imagePath == '' || ImageUploader.api_function == '')
            return false;


        setTimeout(function () {
            // do your thing here!
            //$("#loading").show();
            MaraMentor.ShowLoader();
        }, 1);

        var options = new FileUploadOptions();
        options.headers = {
            Connection: "close"
        }
        options.fileKey = "file";
        options.fileName = ImageUploader.imagePath.substr(ImageUploader.imagePath.lastIndexOf('/') + 1);

        var picName = options.fileName;
        if((picName).indexOf(".") === -1)
             {
                 options.fileName = options.fileName+".jpg";
             }
             else
             {
                 fileExtension = picName.substr(picName.lastIndexOf('.'));

                 //alert(fileExtension);
                 if(fileExtension===".jpg" || fileExtension===".png" || fileExtension ===".jpeg"){
                 }else{
                    options.fileName = options.fileName+".jpg";
                 }
             }

        options.mimeType = "image/jpeg";

        var params = new Object();
        params.user_id = MaraMentor.sessionId;
        params.func = ImageUploader.api_function;
        params.source = "camera";
        //params.parameters =

        options.params = params;
        options.chunkedMode = false;

        var ft = new FileTransfer();
        ft.upload(ImageUploader.imagePath, serverURL, ImageUploader.ImageUploadSuccess, CommonFailFunction, options);
    },

    ImageUploadSuccess: function(result){
      //result = JSON.parse(result);
      ImageUploader.imagePath = "";
      ImageUploader.api_function = "";
      uploadSuccessResponse =  JSON.parse(result.response);

        if (ImageUploader.page_source == "post_update")
            StatusUpdate.SaveStatusAfterImageUpload( uploadSuccessResponse.data.imageName );

		 if (ImageUploader.page_source == "profile_edit"){
			 EditProfileManager.SaveProfileDataAfterImageUpload();
		 }

      //MaraMentor.HandleBack();
    },
}



UserContactManager = {
	FetchUserContacts : function() {
		if ("true" == window.localStorage.getItem("isContactsFetched"))
			return 0;

		var a = new ContactFindOptions;
		a.filter = "";
		a.multiple = !0;
		contactFilter = ["name", "phoneNumbers", "emails"];
		navigator.contacts.find(contactFilter, UserContactManager.ContactSearchSuccess, UserContactManager.ContactSearchError, a)
	},

	ContactSearchSuccess : function(a) {
		MaraMentor.DeviceContacts = a;
		for (var b = [], c = 0, e = "", f = 0; f < MaraMentor.country_array.length; f++)
			MaraMentor.country_array[f].iso.toLowerCase() == MaraMentor.countryIsoCode.toLowerCase() && ( e = MaraMentor.country_array[f].c_phone_prefix);

		for ( e = 0; e < a.length; e++)
			if (a[e].phoneNumbers)
				for ( f = 0; f < a[e].phoneNumbers.length; f++) {
					var c = 0 == e ? 0 : c + 1, h = a[e].phoneNumbers[f].value, g = a[e].name.formatted, h = h.replace(/[()-\s]/g, "");
					if (null != h &&
					void 0 != h && "" != h) {
						if (null == g ||
							void 0 == g || "" == g)
							g = h;
						b[c] = {
							formattedName : g,
							phoneNumber : h
						}
					}
				}
		b.sort( function(a, b, c) {
			var e = c ? function(b) {
				return c(b[a])
			} : function(b) {
				return b[a]
			};
			b = [-1,1][+!!b];
			return function(a, c) {
				return a = e(a), c = e(c), b * ((a > c) - (c > a))
			}
		}("formattedName", !0, function(a) {
			return a.toUpperCase()
		}));
		e = "";

		for ( f = 0; f < MaraMentor.country_array.length; f++)
			MaraMentor.country_array[f].iso.toLowerCase() == MaraMentor.countryIsoCode.toLowerCase() && ( e = MaraMentor.country_array[f].c_phone_prefix);

		MaraMentor.DeviceContacts = b;
		a = "user_country_code=" + e + "&contacts=" + JSON.stringify(b) + "&fromUserId=" + MaraMentor.sessionId + "&func=contactBook&api_key=92b7d3ab2b864e8eee752fe8e979960c&screen=Medium&platform=bb10";

		MaraMentor.MakeAjaxCall( a, UserContactManager.SendSMSInvitationServerSuccess, CommonFailFunction);
	},

	SendSMSInvitationServerSuccess : function() {
		window.localStorage.setItem("isContactsFetched", "true")
	},

	ContactSearchError : function(a) {
		20 == a.code && MaraMentor.showAlert("Please provide access to your contacts from settings.");
		MaraMentor.HideLoader()
	}
};

var AnalyticalManager = {
	localyticsSession:"",

    Initilize:function(){
    	if( "iOS" == platform )
			AnalyticalManager.localyticsSession = LocalyticsSession("a6e1a6f5a21f43af929d940-70dfbda6-59e2-11e4-26ea-004a77f8b47f");   //For IOS
		else
			AnalyticalManager.localyticsSession = LocalyticsSession("f77cb793bd030ece6f51d3b-ed6b42c4-59e1-11e4-a35b-005cf8cbabd8"); // For Android

		AnalyticalManager.localyticsSession.open();
		AnalyticalManager.localyticsSession.upload();
		AnalyticalManager.localyticsSession.tagEvent("App Launched");
		//AnalyticalManager.localyticsSession.upload();
    },

    Tag:function(eventName){
    	if (AnalyticalManager.localyticsSession =="")
    		AnalyticalManager.Initilize();

    	if (typeof eventName === 'undefined')
    		return false;

		AnalyticalManager.localyticsSession.tagEvent(eventName);
		//AnalyticalManager.localyticsSession.upload();
	}
}

